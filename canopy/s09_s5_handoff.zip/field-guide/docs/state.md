# State of the garden ~ rewildingCities

What is true now. Rewritten, never appended, at every hand-off (D-160). The
build ledger (field-guide/docs/build_ledger.md) is the history; this page is
the present. When the two disagree, the ledger and the code win, and this page
is fixed.

**Updated:** 2026-11-18, at Sprint 09 session 5's hand-off. Sprint 09 is in progress: zip 9b1 is built, run and committed, and the explorer's places map is public (item 6cdfb76c64bb4a59a1ecf34de17d796d, 7 of 7 items as recorded). Session 5 read R5 clean (D-367 holds), settled WTABLE-1 by Esri's web map specification (a web map table is by URL only, D-376), built zip 9b1 on Kalli's word (go with the intuitions, revised against error and drift: D-377 to D-381) and a fix, 9b1a, after the refusal record's dry run caught the write's own refusals counted as the gate's; then ran it: the nine retired, the state outline, five markers copies, the towns' web_250m (ROUND-2 closed: every shape valid after rounding), the refusal record, the told copy, the places map to test and to the explorer. The explorer goes to the library within the delivery window (Kalli). Next: zip 9b2's consultation.

## Where the build stands

- Branch main. Confirm with `git log --oneline -15` and `git status -sb`, and push if it is not yet pushed. Sprint 09 session 5 began at a25d298 (session 4's hand-off), clean; its commits hold zip 9b1 and 9b1a's code and the door's record (54752f3 is the last before this hand-off), then this hand-off.
- Tests: `python -m pytest -q -rs | tail -3`. **1,506 passed** at zip 9b1a: zip 9a's 1,457 plus tests/test_places_map.py (24: sessions 3 and 4's rehearsals in the suite, with a fake portal that stores a whole float as an integer; two need shapely), test_told.py (20) and test_display_markers.py (5, three needing geopandas). The suite needs shapely and geopandas installed to run whole; without them those tests skip.
- Profiles: `python -m canopy.cli profile maine` builds all 1,663 places in about five minutes into plots/maine/.data/place_profile_profiles.json. Rebuilt 2026-11-18 on the fixed standard (D-357) and written canonically (824e79d23b1d). Rebuilt again in session 5 after the retirement: 281851f1fd97, identical to 824e79d23b1d with every `built_at` set aside (D-382), so not written; the bucket's version stays current and the explorer tells it. `canonical maine place_profile_profiles` now says it would write; that is the clock, not a change, and nothing is owed (PROFTIME-1). A change to the standard, the notes or a profile's wording means a rebuild and a new version.
- The telling: canopy/wonder/telling.py turns a profile into the explorer's text fields (D-351). Its register is seeds/language/plain_language.yml (D-352); tests/test_telling.py holds every field to it. `tell_withheld` tells the refusal record on the state's row (D-376, D-378); its type names are still working vocabulary (PLAINWORDS-1).
- Plan of record: the Master Plan, https://claude.ai/artifact/KpQRRSTyXr27emXnJFfL6z. Its Sprint 08 tab is marked done at this hand-off. Check its claims against this page and the code.
- Next decision ID: **D-383**. Before minting any ID, grep the ledger for it **before** appending a block that names it: a block's own line satisfies a later grep (session 2). Item IDs too.
- **Sprint 08 is closed** (session 2). Progress: field-guide/docs/progress/infrastructure/sprint-08.md. **Sprint 07 is closed** (session 2 of Sprint 07). Progress: field-guide/docs/progress/infrastructure/sprint-07.md.
- **The canonical bucket.** Kalli's account, us-east-2 (D-301). REWILDING_CANONICAL_BUCKET and REWILDING_CANONICAL_DOMAIN are set in the rewilding env (`conda env config vars`), never in the repo; the write assumes rewilding-canonical-writer through the rewilding-writer profile. CloudFront: dvk5mp17wovwb.cloudfront.net.
- **Canonical objects written** (every write public and permanent; dry-run first, one artifact at a time, read the pointer and data back after):

| Harvest | Version | Allow record | Rows | Display copies |
| --- | --- | --- | --- | --- |
| clerk_offices_points_points | 0b91cb0caae7 | 33ce1ddb61dc | 392 | `web` |
| outline_towns_outline | eda591d0d3ba | a19b45afae02 | 528 | `web_25m` (sha 4a33d5a1..., 9.5 MB, opened at 2 places, D-356); `web_250m` (sha 15b4ecdb..., 2.0 MB, every shape valid after rounding, D-369, D-379) |
| outline_house_outline | 146e0ca3ac11 | 579be49bc2e6 | 151 | `web_25m` (sha ed297340..., 9.1 MB, opened at 4); `markers` (sha 3b0ae4cd...) |
| outline_senate_outline | c603add2e7f6 | 7f60539a73e8 | 35 | `web_25m` (sha 93700774..., 8.7 MB, opened at 2); `markers` (sha b28c7a05...) |
| outline_tribal_outline | 57e9ac56a143 | f3b47cbb5540 | 8 | `web_25m` (sha 6250b764..., 0.2 MB); `markers` (sha aa50be62...) |
| outline_state_outline | c15851b5bb9b | ef0603f94c6b | 1 | `markers` (sha 7714b6f8...), written in session 5 for the explorer's state level (D-376) |
| place_profile_profiles | 824e79d23b1d | cfeaf7315c54 | 1,663 places | `told_20d8f35f247e` (sha 5e5f8503..., 2.3 MB, 740 places told with refusal record dddf81863049, D-370, D-381) |
| _refusals (the refusal record, D-363) | dddf81863049 | none (the gate's own words) | 8 withheld by the gate; validate_counties_checked and validate_towns_checked named apart, refused by the write before the gate | |
| broadband_standardize_standings | fd9fdf0a4a0a | a5f55ad0b26b | 3,222 | `outline_counties_outline_ee88e4f41db3_web_25m` (sha 10e23ac0..., 8.6 MB) |
| outline_counties_outline | ee88e4f41db3 | 513d0d01678e | 16 | `markers` (sha 4081e934...) |
| county_count_derive_values | fe7922079828 | f278d116b315 | 16 | none (no honest map yet, D-347) |
| carriers_counts_values | 33d9b4d7b9b5 | 45a517f1117a | 546 | `outline_towns_outline_eda591d0d3ba_markers` (sha c8b87ff3..., 0.6 MB) |

- **The door's items** (nu.maps.arcgis.com, owned by RDS_NU; recorded in plots/maine/publish/published.yml; on 2026-11-18 both broadband items were restyled (RAMP-1, UPDATE-1) and `--check` read 3 of 3 test and 2 of 2 library items as recorded). The explorer target (folder rewildingCities explorer, public, D-359) holds the places map since session 5. Session 5's `--check` read 7 of 7 as recorded, each item's sharing also compared with its target's (D-372):

| Target | Record key | Item | Sharing |
| --- | --- | --- | --- |
| test (folder rewildingCities test) | clerk_offices_points_points | 0c0a156a19424f5387407f7b0a31360e | private |
| test | broadband_standardize_standings/outline_counties_outline/cii_broadband | 8bc720015fc5458e91c05cd899be8ff9 | private |
| test | carriers_counts_values/outline_towns_outline/news_outlets_per_1000 | d4f7c29e7c5f40fd9b2e5bfb97b0a22b | private |
| library (folder press-forward) | broadband_standardize_standings/outline_counties_outline/cii_broadband | 2ebb4f3e97bc4f86ad9af43f016cacc5 | organization |
| library | clerk_offices_points_points | cac536bb95a2415086ea53f4dbe52af3 | organization |
| test | places (arcgis_places_map, D-371) | 865b9979d41843e2a4c3fe2ff696e734 | private |
| explorer (folder rewildingCities explorer) | places (arcgis_places_map) | 6cdfb76c64bb4a59a1ecf34de17d796d | public |

  The door's first item, 143923c7 (zip 8a), and broadband's first test item, dd56fefa, were found deleted in ArcGIS by the first `--check` (who deleted them is not recorded; Kalli went ahead with `--replace`) and remade; each new entry keeps the old in `previous`. **An item id is what an Experience Builder app holds, so a door item is never deleted by hand once anything is built on it** (Sprint 09).
- The hand-made web map 5fcd410b007a49aaa279e6a2b548f507 (D-325) sits outside the door's record.
- **Rehearsal items, outside the door's record, never the explorer:** the places web map 000c5dcf102f4b878562a0494b6ee7fa (session 3; rewildingCities test, private; five layers, 738 places; tests/rehearsals/sprint-09/places_webmap_sent.json records what was sent); session 2's Feature Collection item and its Map Viewer web map 5dcd073073f24f3398cb2a5514e22517, both found public though made private, cause unknown. Experience Builder's R2 work in session 3 changed neither sharing nor the stored map, so that cause is elsewhere. Session 4's shapes map 7079e2b4d1234db48f12ac1dcbe51478 (rewildingCities test, private; towns as shapes at 250 m rounded to 1 m, every other level a point, tribal points drawn last; 3,791,371 bytes, stored SAME as sent; tests/rehearsals/sprint-09/places_polygons_sent.json records it). R5 has not yet been read on it.
- **Experience Builder, as read in session 1** (D-350): its Map widget draws a door map's referenced GeoJSON, and no widget can read it. Search reads a feature collection; a widget that should follow a search connects to the Search widget's **output** data source (Select data, Outputs), never the searched data. Its published config is the item resource config/config.json. The rehearsal app read_9a (05b3d08a86174f78a725e77e7d833a1e, RDS_NU) holds an Arcade test source wired Search to Text, Embed and Table; it was public and Kalli was asked to make it private; confirm. It is a rehearsal space, never the explorer. Session 3: a Map widget on a web map that holds feature collections works, and a Search choice moves the map, Text and Table together.
- Kalli has explicit permission to publish as RDS_NU for this project; its password is typed at the door's prompt and never stored, logged or committed.
- **Sprint 06 is closed** (Kalli, session 16). Carried forward, not done: step 7b, the FCC map (P-6, the first cut); step 10, the pairing table (P-2, after delivery); OWN-1's ledger check.
- **Delivery, as Kalli set it in session 16:** the door, the kit and the canonical files in S3 for December; the explorer (Sprint 09) after. Revised 2026-11-18 (Kalli): the explorer goes to the library within the delivery window, so 9b2 is due in it too. Clerk offices as points and outlets at their towns on the map, the aggregate counts kept for analyses. The cloud stack is tested on Kalli's own AWS account and handed to the library as code.
- On or after 2026-12-02, when the 133rd's rosters are acquired: flip available: true, TRIBE-4, SEN-1, then run maine_seats.
- HRSA's sites copy, the Section 203 release, the PIAAC workbook, the clerk list and the 911 file live in plots/maine/.data as before (sha256s in the manifest). The 911 file holds home addresses and never leaves .data; since D-337 the canonical write refuses any receipt whose data file is a manifest dataset's cache, and a test walks every plot.
- Retired receipts: plots/maine/.data/retired/ holds derive_values and standardize_standings, the broadband experiment's receipts from before its steps were renamed (D-336), and since session 5 the nine stale receipts with their data files (D-373): outlets_disagreements_disagreements, outlets_groups_groups, outlets_stack_stack, dissolve_counties_dissolved, repair_counties_repaired, repair_towns_repaired, units_dissolve_dissolved, units_geoid_with_geoid, units_repair_repaired. Held after: 49 receipts, 37 may leave, 12 withheld. Moved, never deleted: loam unions every receipt left in .envelopes.
- The Census key is set in the rewilding env and is replaced (KEY-1).

## Sprint 09 ~ the explorer (in progress)

Session 1 built zip 9a and ran it. The explorer's shape (D-350, revised by D-361): an Experience Builder app owned by RDS_NU, featured on the library's Hub page. Its places live inside one door web map, one feature collection layer per level, every field from the telling; Search, the profile panel and the Map widget all read that map, and no separate places item is made.

Session 4 settled how the places are drawn and split 9b in two (D-367 to D-375):

- **Towns as shapes, every other level a point** (D-367), at 250 m, from a canonical display copy of the towns' outline (D-369), under one rule: never send an invalid shape (D-368). Tribal points are drawn last, so a click on a dot answers the nation and a click elsewhere on the shape answers the town (STACK-1). This rests on R5 reading on the shapes map; if a click on a shape does not move Text, D-367 reopens and points carry the places map.
- **Zip 9b1** (D-375): the told copy written canonically (D-370); the places map as its own door path and entry kind, with `check()` comparing D-362's hash and every item's sharing with its target's (D-371, D-372); the nine stale receipts retired and the refusal record written (D-373, D-363); Contracts 1, 2 and 4 raised.
- **Zip 9b2** (D-375): the values tables written and joined, the pillar crosswalk (its shape D-374, its placements read first), five lens maps (D-365), `--adopt-app` (D-366), the guide for building the app by hand.

Session 5 ran zip 9b1 whole (D-376 to D-382): the places map is public in the explorer folder, six levels, 739 places drawn (Penobscot Indian Island Reservation, 2300357936, left out and named: no land face, INDIAN-1), 3,995,923 bytes, stored SAME as sent. The state's row tells the refusal record. What is left for Sprint 09 is zip 9b2 and the app itself.

Contract 4 said the door makes no ArcGIS item of a profile; the places map reverses that line, and 9b1 raises Contract 4 and records why: the places are copied into the map's JSON (file storage, no hosted feature layer), from a told copy the bucket holds.

## Decided in Sprint 09

| ID | One line |
| --- | --- |
| D-350 | Experience Builder draws a referenced GeoJSON layer and no widget reads it; Search reads a feature collection and steers other widgets through its output data source; the explorer stays Experience Builder, its places a door-pushed feature collection (file storage) |
| D-351 | canopy/wonder/telling.py: six levels, 740 places, MEGIS divisions out; sentences from structured parts, never working text; 3.2 KB a row at the median, 2.5 MB in all |
| D-352 | seeds/language/plain_language.yml: grade 9 at each field's median place, claim words refused, no working id; "Where the data is stored"; the range statement reworded (Kalli) |
| D-353 | RAMP-1: darker means harder; a standing's lowest fifth darkest; a value darker in its declared worse direction, recorded as join.directions when a copy is drawn; no direction, no colours |
| D-354 | owed() owes a restyle when the door's renderer changes, by the move's path |
| D-355 | plots/<plot>/publish/credit.yml: credit, citation ({title}, {version}, {url}), data guide line; refused when incomplete |
| D-356 | COVER-1: a pinch, not a crack; the copy moves pinched hole vertices 0.1 m into their holes, recorded as `opened`; canonical outlines unchanged |
| D-357 | The CII published measures acquirable (terms of use, CII-19); Cision out of the outlet sources; the last post needs our own model |
| D-358 | A note may carry status: draft, told as "Draft wording"; tribal_representation_legislature added as a draft, with its sources |
| D-359 | The explorer target: public, folder rewildingCities explorer, RDS_NU (Kalli) |
| D-360 | The credit and citation name Northeastern University Library (Kalli) |
| D-361 | The places live inside one door web map, one feature collection layer per level; no separate places item. Rehearsed in session 3: 738 places stored in 2,351,336 bytes, every count back, Search moves the map and widgets (Kalli) |
| D-362 | A places map's canonical form writes every whole float as an integer, and the door sends, records and checks that one form: ArcGIS stores 5615270.0 as 5615270 (16 coordinates, the whole 32-byte difference) |
| D-363 | Fork 1: the withheld table is told from a canonical refusal record of the gate's refusals only, under harvests/ with a name no receipt can take, versioned by content; `--check` reruns the judgment and says stale; rows are kinds of data, naming no withheld outlet; the nine stale receipts are moved to .data/retired first, unless a live reader needs one, which is rerun instead (Kalli) |
| D-364 | Fork 2: a target names a portal account and each recorded entry names its kind; an entry with no kind is refused, the five recorded entries get theirs written; a feature collection layer moves by its collections' hash, never a URL; the description names both hashes; the door's opening line says what it now stores (Kalli) |
| D-365 | Fork 3: five lens maps always, since an app holds item ids; an empty pillar holds the orientation outlines and says so; "measured, not yet mapped" (literacy) is told apart from "not yet measured", from one home shared with the profile; every value drawn declares a direction; values only, never standings (Kalli) |
| D-366 | Fork 4: `publish --adopt-app` records the hand-built app, refusing one not owned by RDS_NU, outside the explorer folder, or read_9a; `--check` reads its published config (and says so) and compares every recorded item's and the app's sharing with its target's (Kalli) |
| D-367 | The places map draws towns as shapes at 250 m and every other level as a point; tribal points are drawn last (STACK-1). 3,791,371 bytes, stored SAME as sent (session 4). Rests on R5; reopens if a click on a shape does not move Text (Kalli: go with the intuitions) |
| D-368 | Never send an invalid shape: a shaped level is rounded to 1 m; if any place comes back invalid, emptied or with a ring collapsed, the whole level is rounded to 0.1 m, so neighbours keep one edge; if that fails, the level is refused and named. Held by a test. The read found every failure in the rounding, none in the outlines or the simplifier |
| D-369 | The towns' shapes come from a canonical display copy (`canonical maine outline_towns_outline --display --tolerance 250`, web_250m), so the simplification has an envelope the gate judges; the door only projects (its _mercator), rounds, winds rings Esri's way (outer clockwise) and applies D-368, and says each in the description |
| D-370 | The told rows are a canonical display document under the profile's version (told_<inputs sha12>.json and its envelope), named by the hash of everything the telling reads (telling.py's version, the standard, the notes, plain_language.yml), so a changed seed is a new name and never new bytes under one (D-322). A `told` step joins rule 11's closed set; Contract 2's section 4 says a display copy may be a document. The door reads the told copy, never the profile (Sprint 07's goal: the truth that leaves is written once, outside AGOL) |
| D-371 | The places map is its own door path, `publish <plot> --places`, entry kind arcgis_places_map under the key `places`, owed a move when the told copy, any outline or the towns' copy moves. A target's `kind` names the portal it speaks to (arcgis); each entry's `kind` names what the door made (arcgis_webmap, arcgis_places_map); an entry with none is refused. Revises D-364's mechanism: the five entries already named their kind |
| D-372 | `check()` compares a places map by the D-362 hash of its stored JSON, never a layer URL, and compares every recorded item's sharing with its target's, not only its record's |
| D-373 | WITHHELD-1's exact-name read: no live reader names any of the nine stale receipts (only each other's receipts, test fixtures, the receipt-name table and an old demo page), so all nine move to plots/maine/.data/retired with their data files, never deleted. Held after the move: `canonical maine --all` reads 49 receipts, 37 may leave, 12 withheld (8 by the gate, 4 by the write), and a profile rebuild still writes 824e79d23b1d; either missing means a read was wrong |
| D-374 | The pillar crosswalk is national (seeds/crosswalks/pillars/): a measure joins a CII pillar automatically only when it `replicates` an indicator the weights seed places there (CII's own membership: each of its 27 in exactly one pillar, so none in two); any other placement is a declared row with its reason in words, defined_by rewildingcities, told on the map as ours. The placements wait for seeds/indicators/language.yml and carriers.yml to be read (9b2) |
| D-375 | Zip 9b is two zips: 9b1 (told copy, places map path, entry kinds, wider check, retirement and refusal record, Contracts 1, 2 and 4) and 9b2 (values tables, crosswalk, lens maps, `--adopt-app`, the guide), each designed in a short consultation and built in a fresh chat |
| D-376 | WTABLE-1: a web map table is defined by a URL to a service table and holds no feature collection (Esri's web map specification), so the withheld rows are told in one field, `withheld`, on the state's row, and the state joins the places map as a sixth level, a point. Told from the refusal record, never typed into a widget |
| D-377 | Every level but the towns is drawn from a canonical `markers` copy of its outline (`canonical <plot> <outline> --display --markers`), one point on each place's own surface, recorded `marked`; the door stays geopandas-free |
| D-378 | telling.py writes the withheld field (`tell_withheld`); the refusal record's version is in the told copy's name, so the record is written first; it is named in the told entry's params, never as an input, since an input's type binds rule 2 |
| D-379 | ROUND-2: a polygon copy's `rounded` record names every shape its rounding leaves invalid, or says every shape is valid, and is never refused for it; the door refuses to send one (D-368). The towns' web_250m read: every shape valid |
| D-380 | The door owns the whole places map: `check` compares the D-362 hash of its stored JSON, any other change reads as changed by hand, a move rewrites it whole (narrowing D-328 for this kind) |
| D-381 | D-370 revised: the told copy is named by the hash of told.py, telling.py, place.py, the notes and plain_language.yml, and the refusal record's version; the standard reaches the telling only through the profile's version |
| D-382 | A profile rebuild's hold is the same places with every `built_at` set aside, since the profile stamps a time into every place and no rebuild can repeat its version. Read in session 5: identical, so D-373's retirement changed nothing the profile says, and the bucket's 824e79d23b1d stays current |

## Sprint 08 ~ the publish door (closed in session 2)

**Goal:** one door publishes every result: through the gate, from the canonical store, to each target a plot declares, updating in place and carrying its provenance.

**Done when, met (session 2):** broadband published twice to test left one layer (`unchanged`, no sign-in); one layer in each of test and library; each description names its canonical version's sha256. `publish maine --check` then read all five recorded items as recorded.

**Zip 8a, the door (session 1, D-326 to D-334).** `python -m canopy.cli publish <plot> <artifact> --to <target>`, a dry run unless `--write` with `--by` and `--reason`; targets declared by each plot in plots/<plot>/publish/targets.yml; the record in published.yml beside it; REST through requests, no Esri package; generateToken with a prompted password, then community/self must name the owner; the door owns only the layer's URL and fields, the description and the credits.

**Zip 8b, the second half (session 2, D-335 to D-347, with 8b2).** canopy/choropleth.py holds the one keyed join, (unit_authority, unit_code) to (authority, code), which map.py imports (LAYER-1 closed). `canonical <plot> <table> --display --join <outline>` draws one wide copy under the table's version, named for the outline's version, with both parents in its envelope; `--markers` draws one point inside each place, so COVER-1 never binds markers; `--local` draws from the bytes a write would send, with no AWS, and its sha256 must match the bucket draw's. The gate reads the outline's lineage for rule 10. The door publishes a choropleth with `--join --indicator [--markers]`, keys its record `<table>/<outline>/<indicator>`, owes a move when either parent moves, checks notes and credits against both allow records, and owns the renderer (standings in fifths of the named reference population; counts as markers in equal steps with "none listed" its own class; no value hatched). Two guards on the canonical write: an orphan receipt is refused (D-335), and so is a receipt whose data file is a manifest dataset (D-337). The library target: press-forward, organization, no groups (D-346). DOORSAY-1 and DOORCHECK-1 closed.

**Found while running (session 2):** state.md had labelled two county receipts wrongly (1b9c5a6e8d71 is rent burden and vehicle access; fe7922079828 is households without broadband); broadband's standing was `standardize_standings`, a name the method's recipe gives every composed experiment, so its steps were renamed (D-336) and two guards added. Rule 11's closed set lacked `joined` and `marked` (D-348). pyproj's placeholder "unavailable until proj_trans is called" was written into copies' records, now said in words. ArcGIS Online decodes `&#x27;` in stored descriptions, so the door's sent-text hash called every item hand-edited until zip 8c read descriptions back (D-349).

**Not done, and why:** MCF and partner targets (build item 2): none declared, because neither has given a portal and an owning account; a target is a few lines of targets.yml when one does. F3, F7 and F8 of the publish route assignment were never found and are not reconstructed (D-334). A real `update` call has never been answered by ArcGIS: every item so far was made by addItem (UPDATE-1).

## Sprint 07 ~ storage outside AGOL (closed)

**Goal:** the truth that leaves is written once, outside AGOL, in a bucket that cannot overwrite it, readable by URL from anywhere.

**Zip 7a, the stack (session 1, D-301 to D-311).** One Terraform stack in canopy/terraform (D-306): a private, versioned bucket, TLS-only, SSE-S3 with SSE-C blocked, Block Public Access on, noncurrent versions kept (D-307); CloudFront with origin access control reading harvests/* alone, CORS for any origin, versions cached long and current never (D-302, D-310); the writer role, put, get and list under harvests/, every delete denied, no access key (D-308); the bucket policy as the overwrite lock for every principal (D-309); access logs; the budget switched by create_budget (D-311). Applied on Kalli's account in us-east-2, the project's assigned region, because an organization policy refuses S3 in us-east-1; the committed default stays us-east-1 for the handover. The README holds the order of apply and the handover addendum.

**Zip 7b, the canonical write (session 2, D-312 to D-320).** canopy/aws/s3.py and `python -m canopy.cli canonical`. A receipt from the plot's .envelopes, its data in the plot's own .data (D-312), is judged by the gate at canonical, public (D-315). The receipt travels byte for byte as envelope.json; the allow record lives beside it, versioned by its own content (D-313, D-320). Parquet and JSON are written as they are; GeoJSON becomes GeoParquet, converted twice and refused if the two differ, the change recorded as format_changed by the canonical write (D-314). A custom tier is refused until O-6. The command is a dry run unless --write, which takes one artifact with --by and --reason (D-316). Data is put last; current moves with If-Match (D-317). A harvest's name is its artifact's (D-318).

**Zip 7c, display copies (session 2, reopened, D-321 to D-325).** canopy/aws/display.py and `canonical <plot> <artifact> --display`: drawn from the current version's own bytes read back from the bucket and checked against its sha256, written under the version's display/ (D-321); points named web, polygons web_<tolerance>m, a name never given new bytes (D-322); an envelope inheriting the version's lineage, notes and chain, with its own make_display_copy entry recording simplified, rounded and format_changed, schema-checked and judged by the gate (D-323); polygons simplified as one coverage in EPSG:26919, 25 m by default, an invalid coverage or an emptied geometry refused; points simplify nothing, said with count 0; six decimals; GeoJSON in EPSG:4326 naming pyproj's operation; dates as ISO 8601 text, each such field named (D-324). In ArcGIS Online a copy is referenced through Map Viewer's Add layer from URL; the Content route imports GeoJSON and is not used (D-325).

**The dry run (session 2):** 37 of 58 may leave, 21 withheld, 0 unjudged. Withheld: rule 5 for the outlet listings, groups and stacks; rule 9 for all five carriers' located_in_edges (EDGE-NOTE-1); rule 10 for the old outlets_* receipts, which still carry Cision from before D-294; rule 4 for eight receipts with no lineage (RECEIPT-1's chain; six in Sprint 09 session 2's read); literacy and section 203's CSVs by format (both reach the public through the profile). May leave: every outline, every carrier's counts and points, every indicator table, the profile.

## Sprint 06 ~ the place profile and the standard (closed in session 16)

**Goal:** every Maine place has a six-part profile, its carriers are on the map, and every barrier is judged against a stated, absolute standard.

**Decided in the design pass:** D-197 (build_profile wraps read_place), D-198 (margin-aware verdicts, derive_margins), D-199 (universal, trigger, none thresholds), D-200 (each barrier a family of registered indicators with a status).

**Decided in session 1:** D-201 to D-209. **In session 2:** D-210 to D-212. **In session 3:** D-213 to D-217. **In session 4:** D-218 to D-222. **In session 5:** D-223 to D-226. **In session 6:** D-227 to D-229. **In session 7:** D-230. **In session 8:** D-231 to D-233. **In session 9:** D-234 to D-239. **In session 10:** D-240 to D-246. **In session 11:** D-247 to D-252. **In session 12:** D-253 to D-257. **In session 13:** D-258 to D-269. **In session 14:** D-270 to D-282. **In session 15:** D-283 to D-293. **In session 16:** D-294 to D-300, below.

**Order of work, and where each step stands:**

```
 1  P-9: read the outlet files                done      answered
 2  located_in edges + end checks             done      D-207
 3  carriers, counted per 1,000               done      libraries, schools, health centers, clerks' offices, outlets
      libraries (IMLS PLS FY 2024)            done      D-208 to D-212: placed, counted, closures declared
      first, by Kalli's order (session 2):
        SCHEMA-2: the method schema           done      D-213 to D-217
        CMAP-1: the carrier map as a view     done      D-218, D-219, D-223 to D-226
        the drift CMAP-1's walk found         done      D-220 to D-222
      the drift session 6 found               done      D-227 to D-229; INDFILE-1 closed
      schools (NCES EDGE 2024-25)             done      D-230: 598 placed, counted
      the year rule SURVEY-1 hid              done      D-231: boundary_vintage
      health centers (HRSA, 2026-11-14 copy)  done      D-232: 168 placed, 24 listed
      tribal areas counted beside a note      done      D-233; TRIBE-8, LOAM-2 closed
      clerks' offices (GEO-1)                 done      D-234 to D-239: 390 offices, 458 of 560 rows
        GEO-4: reviewed matches               done      D-240: 392 offices, 468 rows; 1575R reads 1
      outlets, placed by town (WHERE-1)       done      D-241 to D-246: 460 placed, 65 listed
        closed, local news, where             done      D-247 to D-252: 90 placed, 435 listed
        read whole, reviewed with sources     done      D-253 to D-257: 97 placed, 405 listed;
                                                        OUTCONF-1 before publishing
 4  derive_margins (D-198)                    done      D-258 to D-260: inside derive_indicator,
                                                        R and Python, oracle-held; the count kind
 5  language: ACS, safe harbor, section 203   done      D-261, D-263, D-264, D-267: C16001 at five
                                                        levels; section 203 read as published
 6  literacy: PIAAC county estimates (P-7)    done      D-265, D-268: Skills Map, 17 rows
 7  digital access counts + FCC map (P-6)     7a done   D-262: the rate's own complement;
                                                        7b (FCC) not yet, the first cut
 8  outlets reconciled                        mostly    stacked, grouped, reviewed (D-253 to D-257);
                                                        ownership concentration exists (Kalli,
                                                        session 12); check OWN-1 in the ledger
 9  profile.py + the standard seed            done      D-270 to D-293 (sessions 14, 15),
                                                        b3426b1: the standard, verdicts.py,
                                                        profile.py, the profile command
10  pairing table (P-2)                       after     part 6 ships present and empty, its
                                                        reason said (D-285, Kalli's cut)
11  profiles for every place                  done      1,663 places, every level (D-292);
                                                        the gate first (D-284, D-293)
```

**Schools, done (session 7).** Placed from NCES EDGE Public School Locations 2024-25 (D-230): one national release zip (sha256 9dc51ecd...cffb288, in the manifest's known_issues), its headerless text table read through seeds/crosswalks/schools/nces_edge_geocode.yml. 598 schools placed, none listed; the three Wabanaki community schools (OPSTFIPS 59, the Bureau of Indian Education) placed and flagged, one located_in edge per drawer each, Indian Island School in 2301957936 (the Penobscot County piece) and 2760R. Maine counts 598, 0.439 per 1,000 of 1,362,359 persons; Penobscot Indian Island Reservation counts 1 among 370, shown beside its note since D-233. Maine DOE's 13 exports carry no ID and no school's coordinates, so they place nothing; their name lists may serve as a check later (seeds/sources/maine_doe_schools.yml, an export source: only our copy is evidence). MEGIS's school layer carries no state or NCES school ID either. The EDGE characteristics layer (status, grade span) could not be downloaded; the CCD directory, joined on NCESSCH, is in reserve if the DOE check needs the state school ID (its public-use terms limit use to statistical purposes).

**Health centers, done (session 8).** Placed from HRSA's Health Center Service Delivery and Look-Alike Sites, the copy downloaded 2026-11-14 (D-232): a daily snapshot with no release, so the copy is the evidence, declared by its day and sha256, and every row's Data Warehouse Record Create Date is held to the day. Read through seeds/crosswalks/health_centers/hrsa_health_center_sites.yml (header names, codes; an undeclared code refuses). Maine: 192 rows, 168 placed (32 seasonal, 8 look-alikes, every setting), 24 listed (10 administrative, 9 mobile vans, 5 with no point). Maine counts 168, 0.123 per 1,000. No Wabanaki nation's clinic appears; HRSA's program does not see them.

**Clerks' offices, done (session 9).** Town offices became the municipal clerk's office (D-236): where a person registers, asks for a record and puts a question to the town. The list is the Secretary of State's clerk CSV (560 rows, MEGIS GeoCode, five column names twice, read by position; names and phones never read). Each street address is matched exactly to Maine's 911 address points (the GeoLibrary FGDB, NG_ADDRESSES, 798,422 points, EPSG:26919) on house number, street and ZIP, the street spelled through USPS Publication 28 on both sides (D-234, D-235, D-238). One point per distinct office, named by the 911 point's SITE_UID; the rows naming it ride on it as the municipalities it answers for (D-237). Ties: one building settles on its bare point (a rule); a campus settles on its one Government - Municipal point when campus_ties says municipal_class, Kalli's choice (D-239). A person's reading of an address no exact match places is a reviewed match (GEO-4, D-240): seeds/crosswalks/clerks/maine_sos_reviewed.yml, keyed by the list's address as written, naming one standing 911 point by SITE_UID with its evidence, day and reader; it applies only to a row the run would otherwise list and refuses the run when no longer needed. Maine: 392 offices for 468 rows (352 exact, 6 building_point, 32 municipal_class, 2 reviewed); listed 64 no_match, 20 tie, 7 no_street_address, 1 number_not_read. Penobscot Nation's office stands in 2760R, Pleasant Point's in 2850R, and Indian Township's, by review (8 Kennebasis Road written, 8 Kennebasis St in the file), in 1575R, which now reads 1. 7 Minden, nine rows, stands on the 911 point labelled Greenville Police Department; these sources do not say whether the clerk shares it, and CARRY-1 keeps landmark and place_type off the map. The note is carrier_seen_on_nations_land (TRIBE-10). pyproj 3.8.0 does not report its operation for 26919 to 4326; the receipt says so.

**Outlets, placed by town (session 10, D-241 to D-246).** Only Local News Catalyst (30 records) and the Maine Media Ecosystem file (81) name a town, 111 of 926 records, which reopened WHERE-1 the day it was decided. maine_outlet_carriers restacks and regroups the five listings under its own step ids, then prepare_news_outlets writes one outlet per group (type news_outlet), its id made from its members in the declaration's source_order, never row order (D-243). A named town places it and always wins; when none is named, Maine's choice town_fallback: office_town places it by Cision's office town name, flagged (D-242). Towns are matched by name after the Census suffixes in seeds/crosswalks/places/census_name_suffixes.yml come off; two towns, no match, two matches or no town are listed (D-244). Operating status comes from operating_vocabulary in outlet_sources.yml; Maine's ceased_outlets: listed (D-245). build_town_located_in places each outlet at town, county and state only, never a district or tribal area (D-246); loam's carriers view leaves the table out by name. Reviews (merges, towns) go in seeds/crosswalks/outlets/outlet_reviews.yml, keyed by source and name as written; none yet. Maine: 460 placed (388 office_town, 72 named_town), listed 28 no_town_given, 21 ceased, 11 no_town_match, 3 towns_disagree, 2 ambiguous_town; operating 312, not_given 141, last_post 7. Portland city counts 121 and Bangor city 67, Cumberland County 191 of 460: the office fallback concentrates outlets where publishers keep offices (OFFTOWN-1), and Cision's types include trade press and blogs (MEDIUM-1). The listings are undated, so the count's time reads undated (UNDATED-1).

**Outlets asked closed, local news, where (session 11, D-247 to D-252).** prepare_news_outlets now asks each outlet three things in order. Closed: operating_vocabulary, and a status written in another column through operating_elsewhere (the ecosystem file writes CLOSED in its Medium, D-251). Local news: source_kinds declares Local News Catalyst, the ecosystem file and Easton local_news_lists, whose membership is the evidence, and both Cision pulls media_databases (D-247); an outlet only a database holds is judged by media_database_types (all 20 Cision types declared, two axes, medium and audience; an undeclared type refuses; 0 declared unknown) under the choice database_alone, Maine: newspapers; a program never counts (D-248). The medium is judged before the town, so no review can place an outlet listed for its medium. Where: a named town wins; a name in statewide_names places an outlet in the state alone, scope state, one edge (D-249: Amjambo Africa); else town_fallback, Maine: office_town_unshared, where an office address two or more outlets give, compared as normalized street plus five-digit ZIP with leading zeros a spreadsheet dropped given back, is a publisher's office and the outlet is listed office_shared (D-250). Every listing declares source.collected "2026-08" in the manifest and the count's time reads "collected 2026-08", held there by a test (D-252, SRCFACT-2). Each outlet row carries scope, vouched_by, database_class and medium_as_written. Maine: 90 placed (70 named_town, 19 office_town, 1 named_state; 74 on a list's say, 16 Cision newspapers alone), 435 listed (327 medium_not_counted, 32 office_shared, 23 ceased, 23 medium_unknown, 19 no_town_given, 6 no_town_match, 3 towns_disagree, 2 ambiguous_town), 525 in all. Portland 18 (17 named), Cumberland County 29 of 90: what concentration remains is the lists' own. Turner's ten Fern Street weeklies and the Maine Trust for Local News' Portland address (20 outlets) are publishers' offices; the 32 office_shared hold publishers, one paper listed several times (Lincoln County News four times) and sections listed as outlets (The Maine Campus), which is OUTREV-1's queue and EDITION-1's question.

**Outlets read whole and reviewed (session 12, D-253 to D-257).** group_outlet_records now reads a trailing ", The" as the name written inverted (D-253: Cision's "Star-Herald, The"), and joins one source's records alike in name key, url key and office address as one record written twice, its key held once, every copy saying same_record_as (D-254). The office address comparison has one home, group_outlet_records.office_key, which prepare_news_outlets imports. Before D-254, Lincoln County News stood as six groups: Cision's copies held its key twice, so the key joined nothing for anyone (D-202). A reviewed merge may hold one source twice only when it says editions, in words (D-255); a review names a record written twice once. office_reads (keep, town, state, list with a reason) read an outlet placed by its office town alone; an unread one stays placed, flagged office_town_unread (D-256). A town review may say state: true in place of a town_code (D-257). seeds/crosswalks/outlets/outlet_reviews.yml holds 5 merges (the Press Herald with its Sunday edition and site; The County with the Star-Herald, folded in January 2025; the Castine Patriot's two list records; Maine Wire twice; the Boothbay Register / Wiscasset Newspaper, one paper from 97 Townsend Ave.), 23 towns and 12 office reads. Claude read them from cited pages; read_by says so, and Kalli confirms each (OUTCONF-1). Every reading places an outlet where its newsroom, office or broadcast license is; the towns it covers stay SERVES-1's. Three papers had been on the map more than once (the Press Herald, the Castine Patriot, the Boothbay Register in three towns), and Cision lists papers that no longer stand apart (the Coastal Journal, into The Forecaster; The Free Press, into the Midcoast Villager). Maine: 97 placed (65 named_town, 26 reviewed, 5 office_town, 1 named_state), 405 listed (326 medium_not_counted, 23 ceased, 23 medium_unknown, 21 office_shared, 8 office_read_listed, 4 no_town_given); 4 edition merges; 4 office towns unread (The Cryer, USM's Free Press, Rolling Thunder Express, Twin City Times); no towns disagreeing. Portland counts 19.

**Zip 3a, counts go public (session 16, D-294 to D-300).** Cision's two exports are their own type, commercial_outlet_listing, excluded, and maine_outlet_carriers stacks only the three lists, named in stack_outlet_sources' use parameter: Cision stays declared in the shared crosswalk and is left out by name (D-294). Choices database_alone none and town_fallback none. outlet_listing, outlet_stack, outlet_groups and news_outlet are aggregate-only (D-295, D-297); indicator_values and place_profile declare aggregates: true (D-296: rule 5's way out had been unreachable). The clerk types are public (D-297). Terms: the 911 file maine_geolibrary_public (D-298); the clerk list factual_directory and Easton's and LNC's lists factual_compilation_counts, which carries requires_tier: aggregate-only, enforced in rule 10 (D-299, Kalli's readings of Feist, not a lawyer's); the ecosystem file project_own_work (D-300). Reviews: Cision's 10 office reads and Rumford Falls Times removed; Maine Morning Star became a town review (state); The County's merge keeps editions (the ecosystem file lists both papers); the Castine Patriot's merge removed (its records now join by name). Maine: 90 outlets placed, 12 listed (10 no_town_given, 2 ceased). Named outlets wait for OUTCONF-1 and the lists' makers' word: every outlet type in the lineage binds, so the lists' tiers and terms move too. The map's outlet layer is two artifacts joined at the town: the counts (aggregate, leaving now) and the listing (news_outlet, leaving later), one GeoJSON display copy per town marker (session 16, for zip 3b).

**Zip 1, the measures (session 13, D-258 to D-269).** Ratio margins are derived inside derive_indicator, in R and in preview.py, the arithmetic's one Python home canopy/indicators/margins.py, held equal by the oracle (D-258): never as a second indicator_values artifact, which loam would refuse (D-172). Every ratio declares relation: proportion or ratio (D-259), by the Census's 2025 statistical testing instructions: ratio fallback flagged in moe_formula, sums by root-sum-of-squares, a controlled part's margin 0; a proportion of exactly 1 is not_derived (D-269). A count kind adds and subtracts cells (D-260). The language family is C16001 at state, county, cousub and both chambers, 26 indicators in seeds/indicators/language.yml (D-261); households_without_broadband is cii_broadband's own complement (D-262). Section 203's 2021 public use file is read as published into section203_records (D-263): 516 Census towns matched, 12 of ours without a record, Penobscot Indian Island (57936) held whole across its county line, and six Census towns no longer ours (Atkinson, Bancroft, Cary, Codyville, Drew, Magalloway: deorganization between the maps) held under census_s203_mcd (D-267); five tribal areas under Census's own codes, attached to no place (D-264); 0 covered. Literacy is literacy_estimates from the Skills Map workbook (D-265, D-268): 17 rows, none flagged, left_out as NCES computes it, modelled partly from race, poverty and education, never combined with its predictors. First read: Aroostook's French, Haitian or Cajun share is 2.29% plus or minus 0.40 of persons 5 and over, about 85% of its limited English and about 1,465 persons; Androscoggin's limited English is 3.35%, two thirds in other groups.

**Tribal areas, counted beside a note (session 8, D-233).** All three carriers count the 8 Census tribal areas, each row carrying context_note: carrier_unseen_on_nations_land (libraries, health centers: all zeros) or carrier_seen_on_nations_land (schools: Indian Township, Pleasant Point and Penobscot each count 1). The notes' words are Kalli's DRAFT in seeds/notes/notes.yml, waiting on the nations' terms (P-8). Four trust lands hold 4 to 202 persons, so their rates are unstable; the count and persons travel with each rate.

**The barriers, their indicators, and where the data is** (as decided in the design pass; P-9 changed three rows' status, session 13 acquired three, session 14 set their standard):

| Barrier | Indicators | Source | Grain | Status |
| --- | --- | --- | --- | --- |
| Not in the right language | limited-English persons by C16001 group (26 indicators); limited-English households; section 203 coverage | ACS C16001 at five levels (D-261); DOJ 2002 safe harbor as our own line (D-271); Census section 203 file (2021, D-263) | every level | acquired |
| Requires digital access | households with no internet subscription (the judged count, D-262, D-272); the rate; no service at the FCC benchmark | ACS; FCC National Broadband Map | count at every level; rate at town and district | ACS acquired; FCC acquirable (7b) |
| At the wrong literacy level | adults 16 to 74 at or below Level 1 | NCES PIAAC Skills Map (pooled 2012/14/17, D-265) | county and state, borrowed elsewhere (D-276) | acquired |
| Lacking cultural cues | languages spoken against languages carriers publish in | ACS and our own observation of outlets | town | needs our observation (OBS-1): no listing carries language |
| Behind a paywall | share of local outlets free to read | our own observation (OBS-1), P-3 | town | needs our observation: no listing carries paywall status |
| Outdated | outlet publishing frequency; observed last post | Cision, the ecosystem file, Easton (frequency); Cision's Still Operates? (last post) | town | acquirable from the stack |
| Not where people look | carriers per 1,000 by type | IMLS, NCES EDGE, HRSA, the Secretary of State's clerk list through Maine's 911 points, the outlet listings by town (done) | every level; outlets at town, county and state | libraries, schools, health centers, clerks' offices counted (D-209, D-230, D-232, D-239, D-240), outlets by town (D-246), tribal areas beside a note (D-233); on the map as loam's carriers view (D-225), adjectives and notes not yet carried (CARRY-1) |
| Not from a trusted source | relational hubs, aggregate-only | consent-governed | as consented | needs_consent (Sprint 16) |

**Still open in Contract 4:** P-2 (pairing table, after delivery, D-285), P-3 (free outlet), P-6 (FCC benchmark, with 7b), P-8 (section 203 on Wabanaki places; on the nations' terms), GAPS-1 (part 5 in the method authors' words). P-1 and P-5 closed in session 14 (D-271); P-7 and P-9 before.

## Decided in Sprint 06, session 1

| ID | One line |
| --- | --- |
| D-201 | Outlet sources read only as seeds/crosswalks/outlets/outlet_sources.yml declares; headers found by declared names; never_read columns refused |
| D-202 | Outlet records grouped by exact url (path kept) and name keys; never one source twice; a key one source holds twice joins nothing |
| D-203 | Place fields keep their meaning: office_* a postal address, named_* a town a source names, served_raw coverage; compared like with like |
| D-204 | An outlet's county comes from the graph through its town; a source's county is a check (Cision's reads Cook, Illinois) |
| D-205 | Outlet listings stay in garden/reference/ (ignored) and are manifest datasets with paths outside the plot |
| D-206 | `$crosswalks.<n>` resolves seeds/crosswalks/**/<n>.yml into params, so freshness sees an edit |
| D-207 | located_in edges are their own type, located_in_edges, one artifact per layer; towns from the 2024 face, districts and tribal areas from the face's 2020 block |
| D-208 | A library outlet is FSCSKEY-FSCS_SEQ; fixed outlets only; bookmobiles listed, never placed; flags kept; the outlet file is Windows-1252 by its own text |
| D-209 | A carrier is a registered indicator, role carrier, derivation located_count, in seeds/indicators/carriers.yml; every place a row, the count beside the rate; loam's statistical rule now judges ACS values only |

## Decided in Sprint 06, session 2

| ID | One line |
| --- | --- |
| D-210 | A library outlet's structure status is declared once, code to meaning and group (open, permanent, temporary); a blank or undeclared status on a fixed outlet refuses the run; permanently closed outlets are listed, never placed (a rule). Codes from IMLS PLS FY 2024 Documentation, Appendix B; 22 left undeclared |
| D-211 | A temporary closure is a method choice, temporarily_closed (listed or placed); Maine chooses listed, following IMLS's own tables, so Atkins Memorial, Corinth, is listed and 261 fixed outlets are placed; the primitive refuses any other value |
| D-212 | A carrier's meaning lives once, in its method; docstring, run header, registry and indicator rationale point to it. A rule (the other way is simply wrong) is a test; a choice (reasonable people differ) is declared. Bookmobiles are a rule |

## Decided in Sprint 06, session 3

| ID | One line |
| --- | --- |
| D-213 | seeds/schemas/method.schema.yml (v2.0) is the one home of a method's shape, additionalProperties false throughout. Every reader loads a method through parsing.load_method_data: an undescribed shape, a key written twice or a default outside its options is refused, every problem named. A run on a refused method is a validate() error. Options are a mapping keyed by option id; an empty value means the choice's description says it; no option carries an id of its own |
| D-214 | requires_primitives is a list of layer/name references, each resolving in its registry; a recipe uses only primitives its method declares; per-method purposes are YAML comments |
| D-215 | produces is a list, even for one output |
| D-216 | garden/methods/index.yml routes only (domain, id, path); a method's name and answers_question_types live in the method; MethodIndexEntry carries neither |
| D-217 | roots/count_by_unit deleted, never registered: count_located (D-209) is the one count of points in places |

## Decided in Sprint 06, session 4

| ID | One line |
| --- | --- |
| D-218 | Each carrier kind is its own semantic type in the domain vocabulary, never one type with a kind field |
| D-219 | institutional_node retired with no alias; IMLS's placed outlets are library_outlet; the unbuilt Maine manifest entry removed; maine_libraries rerun (261 placed, 3 mobile and 1 temporarily closed listed, as before) |
| D-220 | A live declaration names a current type, never an alias or a state-suffixed name: state is provenance, kept in the receipt. Aliases and suffix_fallback stay to read old receipts forward |
| D-221 | Every type live work named is declared (water, forest, neighborhood boundaries; roads, nighttime_lights, population_density; measured_composition) or renamed to its existing home; check_alignment unregistered, its 0-byte file deleted |
| D-222 | The wonder composer drafts current types; the three composed drafts (e6e967, 4ade33, STUB-1's 4a8f59) deleted |

## Decided in Sprint 06, session 5

| ID | One line |
| --- | --- |
| D-223 | Carrier-hood lives in the indicator registry, each indicator's role; IndicatorRegistry.with_role() finds carriers. role carrier and derivation located_count are independent: the map draws carriers that are located_counts |
| D-224 | A located_count names the type it counts (derivation.counts: library_outlet), never a layer label, which a seed may not hold; the label stays in the preparation and the receipt (counted_layer). The orchestrator checks before a run that the counted points are that type, read once, from edges made in the run |
| D-225 | loam's located_in view unions every located_in_edges receipt (LOC-VIEW-1); its carriers view gives every placed point of every located_count carrier, found through the edges receipt's own provenance record. place.py reads an exact count apart by derivation and labels every value by role, reading indicators through the registry |
| D-226 | IMLS's codes (outlet types, structure statuses) are one shared crosswalk, seeds/crosswalks/libraries/imls_pls_outlets.yml, passed whole as `reading`; a release's outlet member and encoding are declared in its manifest entry and held to the run as source_facts; seeds/sources/imls_pls.yml is reference only, pointing to each fact's home |

## Decided in Sprint 06, session 6

| ID | One line |
| --- | --- |
| D-227 | An indicator's declaration_sha256 is taken over its own mapping, canonical, without its rationale; computed when parsed, never by reopening the file. A sibling, a comment or a prose edit never stales a receipt. Weights and reliability unchanged (one declaration per file) |
| D-228 | One experiment per question: county standings answers basic_needs_and_opportunity (rent burden, vehicle access); broadband's county standing lives only in maine_broadband_access_subscription__cii_indicator_values_91b5c0, same method and choices |
| D-229 | The no-curiosity warning names only the gap; advice to become a preparation comes only from the error for a run with a preparation method (a rule, tested) |

## Decided in Sprint 06, session 7

| ID | One line |
| --- | --- |
| D-230 | Schools from NCES EDGE 2024-25, keyed NCESSCH, columns and codes from one crosswalk; a school is in the state where NCES's point stands (STFIP), never its operator's (a rule, tested): the three BIE-operated Wabanaki community schools are placed, flagged and counted in every drawer, once each; DOE and MEGIS place nothing. Kalli's choice A, with her guard that Indian Island counts once, as the county subdivision it is |

## Decided in Sprint 06, session 8

| ID | One line |
| --- | --- |
| D-231 | A count says which boundaries it sits on in each row's boundary_vintage, the one vintage of the edges reaching that level; loam reads it for publishers whose rule says boundary_vintage (rewildingcities), so `time` says only when. Closes SURVEY-1 |
| D-232 | Health centers from HRSA's sites file, a daily snapshot declared by day and sha256, rows held to the day; keyed BPHC Assigned Number. Rules: administrative sites, mobile units, sites with no point, withheld addresses, sites not open or elsewhere are listed. Look-alikes, seasonal sites (as an adjective) and every setting are placed (Kalli's choices); who a site serves stays SERVES-1's |
| D-233 | A Census tribal area is counted, never refused, beside the note its step names (tribal_note), carried on every tribal row (context_note); the words are Kalli's DRAFT, on the nations' terms. loam refuses only the ACS on tribal areas (D-171) and judges each publisher on its own levels (LOAM-2). A tribal code and its persons are AIANNH plus component. A level no edge reaches takes its places' vintage |

## Decided in Sprint 06, session 9

| ID | One line |
| --- | --- |
| D-234 | Maine's 911 address points place an address first, the Census Geocoder second: Census interpolates potential ranges, misses non-residential addresses, withholds in sparse places, and matches one batch differently twice |
| D-235 | The 911 points come from the GeoLibrary FGDB, declared by its information cutoff and sha256, never paged from the live service (whose count and schema differ) |
| D-236 | Town offices are the Secretary of State's clerk list; the carrier is the clerk's office. The 911 classes cannot list them (default Residential) |
| D-237 | One point per distinct office, placed where the matched point stands, named by its SITE_UID; GeoCode a check and serves-key, never a placer (a rule) |
| D-238 | Exact match: house number, street, ZIP; the street spelled through USPS Pub 28 (C1 suffixes, 233 directionals) on both sides; no suffix guessed; ZIP over town |
| D-239 | A tie in one building settles on its bare point (a rule); a campus tie follows campus_ties (Maine: municipal_class, flagged tie_broken_by_class); every settled point carries its candidate count and spread |

## Decided in Sprint 06, session 10

| ID | One line |
| --- | --- |
| D-240 | A reviewed clerk match lives in a seed beside the clerk crosswalk, keyed by the list's address as written; it names a standing 911 point by SITE_UID with evidence, day and reader; placed_by reviewed. Kalli's choice C |
| D-241 | An outlet is where a listing names its town; Cision's office address an attribute; Easton's coverage SERVES-1's; reopened the same session by D-242 |
| D-242 | A named town places an outlet first and always wins; town_fallback (none, office_town) says whether the office town name may place one no listing names, flagged; Maine: office_town |
| D-243 | One outlet per exact-key group, its id from its first member by source_order, never row order; reviewed merges keyed by source and name as written |
| D-244 | Towns matched by name after declared Census suffixes come off; towns_disagree, no_town_match, ambiguous_town and no_town_given listed (a rule); a reviewed town settles only a listed outlet |
| D-245 | Operating status through operating_vocabulary: operating, ceased, last_post (counted, words kept), unmapped (counted); ceased_outlets (listed, counted); Maine: listed |
| D-246 | An outlet is placed by its town code at town, county and state only, each edge with its place's own vintage; never a district or tribal area. Outlets then edges keeps D-224's check; loam leaves a table layer out of the carriers view by name |

## Decided in Sprint 06, session 11

| ID | One line |
| --- | --- |
| D-247 | source_kinds: a local news list's membership is the evidence an outlet is local news; a media database's declared type judges only an outlet no list holds; every type declared, an undeclared one refuses; 0 is unknown, never a class |
| D-248 | database_alone (none, newspapers, print_and_web), default none, Maine newspapers (Kalli's go); a program never counts (a rule); the medium is judged before the town; one counted and one uncounted known type is medium_conflict |
| D-249 | A name in statewide_names places an outlet in the state alone (scope state, one edge, build_town_located_in's scope_field); a named town wins, flagged statewide_also |
| D-250 | An office address two or more outlets give is a publisher's office: flagged office_shared, listed under office_town_unshared (Maine's choice). Street normalized, ZIP five digits, a dropped leading zero given back (a rule) |
| D-251 | A status a source writes outside its operating column is read through operating_elsewhere by declared words (the ecosystem file's CLOSED) |
| D-252 | Each outlet listing declares source.collected in the manifest (2026-08, Kalli); the count's time is "collected 2026-08", held to the manifest by a test until SRCFACT-2 |

## Decided in Sprint 06, session 12

| ID | One line |
| --- | --- |
| D-253 | A trailing ", The" is a name written inverted; the name key drops it (a rule) |
| D-254 | One source's records alike in name key, url key and office address are one record written twice: they join first, the key held once, same_record_as on each copy (a rule); office_key's one home is group_outlet_records |
| D-255 | A reviewed merge may hold one source twice only when it says editions in words; editions where no source is twice refuses; a review names a record written twice once |
| D-256 | office_reads keep, move to a town or the state, or list (reason in words) an outlet placed by its office town alone; refused otherwise; unread ones stay placed, flagged office_town_unread |
| D-257 | A town review names a town_code or says state: true, never both |

## Decided in Sprint 06, session 13

| ID | One line |
| --- | --- |
| D-258 | Ratio margins computed inside derive_indicator (R and Python, oracle-held), never a second values artifact; supersedes D-198's own step, its verdict rule stands |
| D-259 | Every ratio declares relation: proportion or ratio; Census 2025 formulas; fallback flagged; controlled margin 0; every derived margin an approximation; no zero-estimate rule |
| D-260 | A count kind: cells added and subtracted, the sum formula; a one-cell count carries its published margin |
| D-261 | Language from C16001 at five levels, 26 indicators, groups in Census's words; B16001 a named gap |
| D-262 | The digital count is B28002_001 minus _004, the rate's own complement |
| D-263 | Section 203 read as published: cp1252, keyed by LANCOUNT, flags as evidence, towns by five-digit MCD; its own artifact; no stated confidence, so cannot_judge |
| D-264 | Section 203 tribal rows never a town's value, attached to no place, shown on the nations' terms (P-8) |
| D-265 | Literacy from the Skills Map workbook, grpName all, 95% credible bounds and flags, left_out by NCES's recipe; modelled from race, poverty and education, never combined with its predictors; P-7 closed |
| D-266 | The ACS pinned at 2020-2024 |
| D-267 | A Census town split at a county line, or no longer ours, is held whole under census_s203_mcd and attached to nothing; both listed |
| D-268 | Literacy is its own artifact, literacy_estimates, read by zip 2's profile |
| D-269 | A proportion of exactly 1 is not_derived |

## Decided in Sprint 06, session 14

| ID | One line |
| --- | --- |
| D-270 | The standard lives in seeds/standards/information_barriers.yml, its shape in seeds/schemas/standard.schema.yml, generic so another domain can declare its own. Each barrier lists sides; a side has a kind (universal, trigger, none), a statement, a source and who declared it, and names the indicators or artifact measures it judges. Barrier membership has its one home there; the registry keeps only role. The pairing table (P-2) is its own seed |
| D-271 | P-1, row by row (P-1 and P-5 closed). Language trigger: the DOJ 2002 safe harbor as rewildingcities' own line, rescinded 2025-03-21, per C16001 group, residents 5 and over: translate at 1,000, or at 5% with 50 or more; written notice of free interpretation at 5% under 50; else nothing written. Section 203 as published, its four-group limit said. Language universal (P-5): every limited-English resident, our line, UNESCO's 2003 multilingualism Recommendation as its principle. Digital universal: every household, the ITU and UN Envoy 2030 household target, the subscription-versus-access gap said. FCC 100/20 terrestrial declared, acquirable until 7b. Literacy universal: every adult 16 to 74 at Level 2 or above, UIS's level for SDG 4.6.1, our line beyond target 4.6's own words. Cultural cues, paywall, outdated, where people look, trusted source: none |
| D-272 | A universal side is judged once, on its left_out count against zero: below when the count less its margin is above zero, within_margin otherwise; meets is unreachable for an estimate, and says so. Literacy by its credible bounds. The side's other indicators carry judged_on, naming the count. D-269's proportion of 1 never reaches a verdict |
| D-273 | Trigger verdicts: crosses, within_margin, does_not_cross, cannot_judge, margin-aware per group; the safe harbor says which tier. A published determination's verdict is as_published: the publisher decided it, we report it. D-263 stands: no verdict of ours rests on section 203's margins |
| D-274 | Profiles are built by a canopy command, never a sows run ($loam names one artifact, D-163; values live in many receipts): one place_profile artifact with its own receipt, listing every receipt it read. place_profile is tier public (Kalli); the gate binds its whole lineage. The profile's own allow record is decided at the publish door (zip 3), never written inside the file it judges; part 5 carries its inputs' refusals |
| D-275 | loam gains views over the literacy_estimates and section203_records receipts' files, keyed by (unit_authority, unit_code), each row naming its receipt; never through place_values (D-268 stands) |
| D-276 | borrowed_from is a list: every coarser place a value comes from, each with its share of residents from the graph's edges (residents, never adults 16 to 74); no verdict and no left_out on a borrowed value |
| D-277 | An uncertainty's confidence comes from its indicator's declared uncertainty (acs_moe: 0.90), held once; a row's own confidence wins (literacy's 0.95) |
| D-278 | left_out means the people short of a universal line, everywhere a reader sees it; place.py's towns-out-of-range property becomes out_of_range (two lines in test_place_reading.py); graph.py's report key stays |
| D-279 | cii_rent_burden, cii_no_vehicle and their cii_pub twins take role need (Contract 4 part 1; neither is an IFL barrier). Only labels and the carriers view read role; the hashes move, so the cousub, district and county runs and the county standings rerun, no fetch |
| D-280 | Part 1's population is the 2020 Census count from the block spine, what every per_1000 divides by; the households' source is read in the build before it is chosen |
| D-281 | Contract 4 moves to draft 0.4 in zip 2, carrying D-258, D-263 and D-270 to D-280 |
| D-282 | Part 4 pairs one measure only: CII's average literacy score and PIAAC's share at or below Level 1 are different measures, shown side by side in the literacy family, never as a disagreement |

## Decided in Sprint 06, session 15

| ID | One line |
| --- | --- |
| D-283 | Tiers: public for the school, health center, section 203 and literacy types and their releases (U.S. government works), and for located_in_edges (adds no limit; points bind through lineage). Outlet and clerk types stay undeclared |
| D-284 | The gate first: a receipt's values enter a profile only if it may leave at public; a withheld one's refusal does; the receipt's inputs are exactly what entered. judge_receipts is the one home of judging a plot |
| D-285 | Part 6 ships present and empty until P-2 |
| D-286 | Part 1's households are the ACS's, the digital count's denominator; its margin is not carried, said so |
| D-287 | A small sample never stops a verdict: the margin decides; the reliability note travels beside it |
| D-288 | Part 4 subtracts only matching units or two percents of one measure; otherwise both shown, no difference |
| D-289 | A trigger is judged over every value its margins allow (verdicts.tiers_within), never only its two ends |
| D-290 | Maine's town and county boundaries take maine_geolibrary_public: 5 M.R.S.A. sections 2004 and 2005, attribution required; the section 1995 reading is Kalli's |
| D-291 | count_located's receipt names the notes its rows carry, so rule 9 binds exactly those |
| D-292 | Every level is profiled: Contract 4's six first, then the MEGIS divisions, as groundwork, saying so |
| D-293 | The places and edges receipts are inputs of every profile; when withheld, the whole file cannot leave, said |

## Decided in Sprint 06, session 16

| ID | One line |
| --- | --- |
| D-294 | Cision is commercial_outlet_listing, excluded; maine_outlet_carriers stacks the three lists by name (use); database_alone none, town_fallback none; Cision's reviews removed (Kalli's cut) |
| D-295 | outlet_listing is aggregate-only |
| D-296 | indicator_values and place_profile declare aggregates: true |
| D-297 | news_outlet, outlet_stack, outlet_groups aggregate-only; municipal_clerk_office, municipal_clerk_list, address_point_release public; the 911 release never a publish target |
| D-298 | The 911 file takes maine_geolibrary_public by D-290's reading; courtesy ask in the wrap-up |
| D-299 | factual_directory (every member, no selection: the clerk list, public) and factual_compilation_counts (a chosen list: counts only, requires_tier aggregate-only, enforced in rule 10); Kalli's readings of Feist |
| D-300 | The ecosystem file is project_own_work, credited to the project; to confirm with Dr. Mittal |

## Decided in Sprint 07

| ID | One line |
| --- | --- |
| D-301 | Kalli's own account, applied fresh, handed to the library as code; us-east-2 on her account, us-east-1 the committed default; the account id out of the repo |
| D-302 | CloudFront with origin access control in front of a private bucket; it reads harvests/* alone (O-1) |
| D-303 | GeoParquet canonical, GeoJSON display copies, GeoPackage on request (O-2) |
| D-304 | Referenced GeoJSON layers for December; a Parquet feature layer a recorded read after (O-3) |
| D-305 | Tests through an injected fake client, no moto; boto3 in environment.yml; old harvests regenerated, never moved |
| D-306 | One stack, canopy/terraform; storage.tf and the December 2025 stack removed |
| D-307 | Noncurrent versions kept |
| D-308 | The writer role: put, get, list under harvests/; every delete denied; no access key (DEPLOY-1 retires the deployer's) |
| D-309 | The bucket policy is the overwrite lock: versions need If-None-Match, current If-None-Match or If-Match |
| D-310 | CORS for any origin, reads only; range headers exposed for DuckDB |
| D-311 | create_budget switches the budget; false on Kalli's account |
| D-312 | The write takes a receipt by name, its data in the plot's own .data, alone |
| D-313 | The allow record beside the receipt, never inside; the receipt byte for byte |
| D-314 | Parquet and JSON as they are; GeoJSON to GeoParquet, twice, format_changed by the canonical write; other formats refused by name |
| D-315 | Target canonical at public; a custom tier refused until O-6 |
| D-316 | The canonical command: a dry run by default; --write one artifact with --by and --reason; bucket and domain from the env |
| D-317 | Data put last; current moved with If-Match; a revert is a move; versions cached a year, current no-cache |
| D-318 | A harvest's name is its receipt's artifact name |
| D-319 | batch.py and docker-compose.yml removed |
| D-320 | Allow records versioned inside their version, named by content less their times |
| D-321 | Display copies drawn by canonical --display from the current version's bucket bytes, under its display/; the canonical command writes them, the door references them |
| D-322 | A copy's name: web for points, web_<tolerance>m for polygons; a name never gets new bytes |
| D-323 | A copy's envelope inherits the version's lineage, notes and chain, records derived_from and its allow record, and its own entry's publication steps; the gate judges it |
| D-324 | Coverage simplification in EPSG:26919 (25 m default); invalid coverage or emptied geometry refused; points count 0; six decimals; EPSG:4326; dates as ISO text, named |
| D-325 | In ArcGIS Online a copy is referenced by URL through Map Viewer and saved in a web map; the Content route imports and is not used |

## Decided in Sprint 08

| ID | One line |
| --- | --- |
| D-326 | One door, `python -m canopy.cli publish`, a dry run unless --write with --by and --reason; --to repeats; --adopt, --replace, --display; `map --publish` signposts it |
| D-327 | Targets declared by each plot in plots/<plot>/publish/targets.yml, read loudly; the door alone writes published.yml beside it, each item naming the sha256 and allow record it shows |
| D-328 | The door owns only the layer's URL and fields, the description (the notes travel in it) and the credits; a person's style kept; a missing item waits for --replace; a hand-edited URL or description refused |
| D-329 | REST through requests, no Esri package; generateToken with a prompted password, then community/self must name the target's owner |
| D-330 | Institutional owners; a personal one warned about on every run (R7) |
| D-331 | Choropleths by `canonical --display --join <outline>`, one wide copy per table and outline version, coloured by the door's classBreaks renderer |
| D-332 | (zip 8a; see the ledger) |
| D-333 | The web map follows the specification 2.38; fields typed from the copy's values; the description holds no time, so the same records write the same words |
| D-334 | F3, F7, F8 and R1 to R6, R9 of the publish route assignment were not found and are not reconstructed |
| D-335 | A receipt that names its run is written only if that run declares the step and output naming it; a test holds one receipt name per run per plot, known pairs named |
| D-336 | The broadband experiment's steps renamed; its harvest broadband_standardize_standings; the old receipts retired to .data/retired |
| D-337 | The canonical write never sends a manifest dataset's cached file: a validate step's receipt is its fetched source (validate_counties_checked, validate_towns_checked) |
| D-338 | canopy/choropleth.py: the keyed join, wide, every row counted by declared widths; map.py imports it; LAYER-1 closed |
| D-339 | A joined copy lives under the table's version, named for the outline's; joined_to names the outline whole; both chains under branches table and outline; row notes from drawn places |
| D-340 | Markers: one point on each place's surface in EPSG:26919, nothing simplified |
| D-341 | `--local`: a copy from the bytes a write would send, no AWS, never written; its sha256 must equal the bucket draw's |
| D-342 | Rule 10 reads joined_to.lineage; gate_version unchanged, no allow record moves; Contract 1 at 0.8 |
| D-343 | The door's choropleth: two parents owed, notes checked and credits taken from both allow records, key <table>/<outline>/<indicator> |
| D-344 | A choropleth's renderer is the door's: fifths, equal-step markers, hatched gaps; a hand restyle put back on a move and said |
| D-345 | DOORSAY-1: plan lines read "owed: ..."; DOORCHECK-1: `publish <plot> --check` |
| D-346 | The library target: press-forward, organization, no groups (Kalli) |
| D-347 | 8b publishes broadband's standing only; the count waits for an honest map; zero towns drawn; CARRY-1 and EDGE-NOTE-1 to Sprint 09; OUT-REG-1 and PROF-1 after delivery |
| D-348 | Rule 11's closed set gains joined and marked; a test holds every step display.py records to the schema's set |
| D-349 | The door reads each item back after it writes and records description_seen_sha256; an older item owes "reseen", verified against the door's own rebuilt text |

## Contracts

field-guide/docs/contracts/: 1 tiers and the gate 0.8 (a copy with two parents, D-342, D-343; zip 9a added `opened` to section 8's step list without raising the version, so raise it with Contract 4's change in zip 9b); 2 canonical objects 0.5 (the same: `opened` in section 4's list) (joined copies, markers, local dry runs, what may be written at all: sections 4a and 4b); 3 geography graph 1.0 (the grove teammate's review owed; CON3-2); 4 place profile 0.4.

## Where invariants are held

| Invariant | Held by |
| --- | --- |
| Every town has one contains edge from its county | build_place_edges; tested |
| A block's county is its 2024 town's (BOUND-1) | build_block_spine; tested |
| Shares sum to 1 per chamber, per basis | build_place_edges, check_shares; tested |
| Every district touches a town | by construction (D-161); tested |
| Edge ends exist in places | build_places; tested. located_in: build_located_in refuses a `to` end not in places |
| A point's town is its face's; its districts its block's (D-207) | build_located_in; tests/test_located_in.py |
| A point counts in every area it falls in | build_located_in, count_located; tested |
| Vintages match | build_places (D-162); place_values through seeds/vintages/boundaries.yml (D-170); tested |
| Tribal places carry their note and name their area | build_places; tested |
| Every authority is declared, each level under one | seeds/authorities/authorities.yml; tests/test_authorities.py (D-188) |
| District values keyed by chamber | tests/test_district_values.py (D-176) |
| Only a declared count moves along an edge | canopy/loam/edge_rules.py (D-179) |
| Every indicator's universe is declared | seeds/universes/universes.yml (D-181) |
| A run's copy of a source fact agrees with the source | Orchestrator._validate_source_facts (D-192, D-193) |
| An outlet column not declared is never read | stack_outlet_sources; tests/test_outlet_sources.py (D-201) |
| No outlet match is chosen by row order | group_outlet_records; tests/test_outlet_groups.py (D-202) |
| A located_count asks no acquisition for anything | registry; tests/test_located_count_indicator.py (D-209) |
| An exact count is read apart by its method, never ranged; every value carries its role | place.py; tests/test_place_carrier.py (D-209, D-223, D-225) |
| Carriers are found by role, never by a type flag | IndicatorRegistry.with_role; tests/test_located_count_indicator.py (D-223) |
| A located_count's counted points are its declared type, read once, from edges made in the run | Orchestrator._validate_located_counts; tests/test_located_count_validation.py (D-224) |
| No indicator seed names a release, a plot, or a layer label | registry (a layer key refused); tests/test_located_count_indicator.py (D-224) |
| A count reads one layer's edges and names it | count_located; tests/test_count_located.py (D-224) |
| The API's description and the declaration show one derivation | Derivation.as_dict; tests/test_located_count_indicator.py |
| located_in and carriers are views, never files; a layer in two receipts, or points not found through provenance, are refused by name | canopy/loam/graph.py; tests/test_loam_carriers.py (D-225) |
| IMLS's codes are read from one shared crosswalk, never a plot | prepare_library_points.read_crosswalk; tests/test_library_points.py, tests/test_library_preparation.py (D-226) |
| A release's outlet member and encoding are declared once and the run is held to them | source_facts, Orchestrator._validate_source_facts; tests/test_library_preparation.py (D-192, D-226) |
| A mobile or permanently closed library outlet is never placed | prepare_library_points; tests/test_library_points.py (D-208, D-210) |
| A fixed outlet's structure status is declared, or the run refuses | prepare_library_points; tests/test_library_points.py (D-210) |
| A temporary closure follows a choice its method declares | prepare_library_points; tests/test_library_points.py, tests/test_library_preparation.py (D-211) |
| Every method matches the method schema; a run on one that does not is an error | parsing.load_method_data, Orchestrator._validate_method_choices; tests/test_method_schema.py (D-213) |
| Every primitive a method names resolves in its registry; a recipe uses only declared primitives | tests/test_method_schema.py (D-214) |
| The index routes every method file once, by the method's own id and domain | tests/test_method_schema.py (D-216) |
| Each carrier kind is its own type; institutional_node is gone, with no alias | tests/test_carrier_types.py (D-218, D-219) |
| Every type a registry entry, method, manifest, preparation or experiment names is current: declared, never an alias or a state spelling | tests/test_current_type_names.py (D-220, D-221) |
| A draft wonder composes names current types | wondering._compose_steps; tests/test_current_type_names.py (D-222) |
| A registry entry points at a file that exists and holds code | tests/test_registry_paths.py (REG-6) |
| An indicator's hash covers its own mapping without its rationale: siblings, comments, key order and prose never move it; source, weight_by and scale do | IndicatorRegistry, spec_sha256; tests/test_declaration_hash.py (D-227) |
| A run with no curiosity is told it names none (D-64), and never told to become a preparation it could not be | Orchestrator._validate_kind; tests/test_preparations.py (D-229) |
| A school is placed where NCES's point stands (STFIP), never by its operator; one operated elsewhere is flagged | prepare_school_points; tests/test_school_points.py (D-230) |
| NCES's headerless table is read by declared columns with a quote-aware reader; another field count, a header row or a duplicate NCESSCH is refused; M and N are never values | prepare_school_points, seeds/crosswalks/schools/nces_edge_geocode.yml; tests/test_school_points.py (D-230) |
| A school release's member and encoding are declared once and the run is held to them | source_facts, Orchestrator._validate_source_facts; tests/test_school_preparation.py (D-192, D-230) |
| A count's boundaries travel in boundary_vintage from its edges, never its time; a level's two vintages refuse | count_located, loam place_values; tests/test_count_located.py, tests/test_loam_values.py (D-231) |
| Each publisher is judged on its own levels; only the ACS is refused on a tribal area | loam place_values; tests/test_loam_values.py (D-233, LOAM-2) |
| A tribal area is counted only beside a note that exists; its code and persons are AIANNH plus component | count_located; tests/test_count_located.py, tests/test_tribal_counts.py (D-233) |
| A count's note is said with its number | place.py; tests/test_place_carrier.py (D-233) |
| HRSA's copy is the one declared: its rows' record dates are its day | prepare_health_center_points; tests/test_health_center_points.py (D-232) |
| Administrative, mobile, pointless, withheld, closed and out-of-state sites are listed, never placed; an undeclared HRSA code refuses | prepare_health_center_points; tests/test_health_center_points.py (D-232) |
| The clerk list is read by position under its exact header; names and phones never read | prepare_clerk_office_points; tests/test_clerk_office_points.py (D-236) |
| An office is placed only where a matched 911 point stands, once, by its SITE_UID; a row's code never places | prepare_clerk_office_points; tests/test_clerk_office_points.py (D-237) |
| A match is exact on number, Pub 28 street and ZIP; a C1 form in two groups refuses unless the seed resolves it | prepare_clerk_office_points, seeds/crosswalks/addresses/usps_pub28.yml; tests/test_clerk_office_points.py (D-238) |
| A tie settles only by the building rule or the declared campus choice, and says so on the point | prepare_clerk_office_points; tests/test_clerk_office_points.py, tests/test_clerk_office_preparation.py (D-239) |
| A reviewed match names a standing point, only for a row the run would list, and refuses when no longer needed | prepare_clerk_office_points; tests/test_clerk_office_points.py (D-240) |
| An outlet's id comes from its members, never row order; two that would share one add a line, flagged | prepare_news_outlets; tests/test_news_outlets.py (D-243) |
| A named town always wins; an office town places only by the declared choice and says so | prepare_news_outlets; tests/test_news_outlets.py, tests/test_outlet_carriers_preparation.py (D-242) |
| A town is matched only by declared names; two towns, none, two matches or no town are listed, never placed | prepare_news_outlets; tests/test_news_outlets.py (D-244) |
| A review is keyed by source and name as written, and refuses when its words change or the run no longer needs it | prepare_news_outlets; tests/test_news_outlets.py (D-240, D-243, D-244) |
| An outlet is counted at town, county and state only | build_town_located_in, maine_outlet_carriers; tests/test_news_outlets.py, tests/test_outlet_carriers_preparation.py (D-246) |
| A layer placed by town is left out of the carriers view by name | canopy/loam/graph.py _drawable; tests/test_outlet_carriers_preparation.py (D-246) |
| Every source has a kind; a database type is declared or the run refuses; a program and an unknown class count under nothing | prepare_news_outlets; tests/test_news_outlets.py (D-247, D-248) |
| The medium is judged before the town; a review cannot place an outlet listed for its medium | prepare_news_outlets; tests/test_news_outlets.py (D-248) |
| A statewide outlet is placed in the state alone; a state row naming a town refuses | prepare_news_outlets, build_town_located_in; tests/test_news_outlets.py (D-249) |
| A shared office address lists or flags by the declared choice; ZIPs compared as five digits | prepare_news_outlets; tests/test_news_outlets.py (D-250) |
| A missing value is judged one value at a time, across the csv the run writes between steps | prepare_news_outlets, build_town_located_in; tests/test_news_outlets.py (round-trip tests) |
| The outlet count's time is the listings' declared collected month | tests/test_outlet_carriers_preparation.py (D-252) |
| A name written inverted is one name | group_outlet_records.name_key; tests/test_outlet_groups.py (D-253) |
| One source's record written twice is one record, its key held once, across the csv between steps | group_records; tests/test_outlet_groups.py (D-254) |
| An office address is compared in one place | group_outlet_records.office_key, imported by prepare_news_outlets (D-250, D-254) |
| One source twice in an outlet only by a person's edition merge, said in words | prepare_news_outlets.apply_merges; tests/test_news_outlets.py (D-255) |
| An office read applies only to an outlet placed by its office town; an unread one says so | prepare_news_outlets; tests/test_news_outlets.py (D-256) |
| A town review names a town or the state, never both | prepare_news_outlets; tests/test_news_outlets.py (D-257) |
| Every review is keyed by source and name as written and names its evidence, day and reader | tests/test_outlet_carriers_preparation.py |
| A run leaves a declared source out only by naming the ones it uses | stack_outlet_sources.read_use; tests/test_outlet_sources.py (D-294) |
| Maine's outlets never stack a commercial_outlet_listing, and no review rests on a source the run leaves out | tests/test_outlet_carriers_preparation.py (D-294) |
| A term with requires_tier holds only for a dataset whose own type declares that tier; a requires_tier that is no tier refuses at load | gate.decide, records.load_licenses; tests/test_gate.py (D-299) |
| Outlet counts and profiles leave; named outlets and anything with Cision in its lineage do not; a clerk office leaves as a point | tests/test_tiers_and_terms.py (D-294 to D-300) |
| Every ratio declares its relation; a count adds and subtracts declared cells | registry; tests/test_indicators.py, tests/test_derived_margins.py (D-259, D-260) |
| R and Python derive the same margins to the last bit | margins.py, derive_indicator.R; tests/test_derive_indicator_oracle.py (D-258) |
| A negative radicand takes the ratio formula and says so | tests/test_indicator_preview.py (D-259) |
| The language family is 26 indicators, the "less than very well" cells, under the API's 50 | tests/test_derived_margins.py (D-261) |
| Section 203 is read in its declared encoding, keyed by LANCOUNT, flags copied; an AIAN/MCD row is never a town's value | prepare_section203; tests/test_section203.py (D-263, D-264) |
| A split or vanished Census town is held whole, attached to nothing | prepare_section203; tests/test_section203.py (D-267) |
| A literacy share never travels without its bounds; no index or model takes literacy_estimates | prepare_piaac_skills_map; tests/test_piaac_skills_map.py (D-265) |
| The standard matches its schema, and every barrier indicator has one home in it | canopy/standards.py; tests/test_standard.py (D-270) |
| A universal side is below only when its count less its margin is above zero; never meets | canopy/wonder/verdicts.py; tests/test_verdicts.py (D-272) |
| A trigger names only tiers a value inside its margins could be in | verdicts.tiers_within; tests/test_verdicts.py (D-289) |
| Every profile has all six parts; every barrier value its households_behind; every universal verdict its left_out; every margin its confidence; no standing | canopy/wonder/profile.py; tests/test_place_profile.py (Contract 4) |
| A withheld receipt's values never enter a profile; places and edges are always its inputs | profile.py; tests/test_place_profile.py (D-284, D-293) |
| Literacy and section 203 records are views keyed by place, never place_values | canopy/loam/graph.py _plant_records; tests/test_loam_records.py (D-275) |
| A count's receipt names its rows' notes | count_located.output_metadata; tests/test_count_located.py (D-291) |
| The boundaries' license term permits public with attribution | seeds/licenses; tests/test_license_geolibrary.py (D-290) |
| Only an allowed receipt is written, from the plot's own .data, by its own name | canopy/aws/s3.py prepare; tests/test_canonical_write.py (D-312, D-315) |
| A version is written once; current moves only with If-Match; nothing is ever removed | the bucket policy (D-309), s3.write; tests/test_canonical_write.py (D-317), which also reads s3.py's source |
| The same data judged the same way sends nothing; a changed allow record is written alone | s3.allow_identity, s3.write; tests/test_canonical_write.py (D-320) |
| A GeoJSON converts to the same bytes twice, or is refused | s3.convert_stably; tests/test_canonical_write.py (D-314) |
| A custom tier never reaches the canonical bucket | s3._judge; tests/test_canonical_write.py (D-315, O-6) |
| A display copy comes from its version's own bucket bytes, checked against the sha256 | s3.prepare_display; tests/test_display_copy.py (D-321) |
| A display copy records every change, its points' simplification included, and the gate judges it | canopy/aws/display.py; tests/test_display_copy.py (D-323, D-324) |
| Neighbouring polygons keep one shared edge; an invalid coverage or a vanished geometry is refused | display.draw; tests/test_display_copy.py (D-324) |
| A display name never gets new bytes | s3.write_display; tests/test_display_copy.py (D-322) |
| A long-form table joins a place only by (authority, code), every row counted, a duplicate, keyless place or clash refused | canopy/choropleth.py; tests/test_choropleth.py (D-338) |
| A joined copy names both parents, lives under the table's version and is named for the outline's | display.joined_envelope, s3.prepare_display; tests/test_joined_copy.py (D-339) |
| A local copy can never be written | s3.write_display; tests/test_joined_copy.py (D-341) |
| Rule 10 binds a joined copy's outline as it binds its table | gate.lineage_datasets; tests/test_joined_copy.py (D-342) |
| Every publication step a copy records is in rule 11's closed set | seeds/schemas/provenance.schema.json; tests/test_joined_copy.py (D-348) |
| No two runs of a plot write one receipt name, but the named pairs; an orphan is never written | tests/test_receipt_names.py, s3.held_to_run (D-335) |
| A fetched source never leaves through a receipt | s3.source_file, manifest_dataset_at; tests/test_receipt_names.py (D-337) |
| The door owes a move when either parent moves; notes and credits come from both allow records | canopy/expose/publish.py; tests/test_door_choropleth.py (D-343) |
| A description is compared as the portal stores it | publish.described_as_recorded; tests/test_door_choropleth.py (D-349) |
| `--check` writes nothing | publish.check; tests/test_door_choropleth.py (D-345) |

## Open items

Sorted for delivery (Kalli asked, session 8). **Delivery (Kalli, session 8):** the Maine product by 2026-12-01 to 12-11: every place's profile, all five carriers on the map with their toggles and notes (town offices and outlets included, so a geocoder is in scope), the barriers judged against the standard, the publish door, the Docker build. Claude's honest note at session 12's hand-off: step 3 is done, outlets through OUTREV-1; steps 4 to 11 and the door remain, with 16 to 26 days to the window. Kalli's shape (session 12): three zips, each designed in a short consultation, then built whole (see Starting the next session). Step 8's ownership concentration exists (Kalli); the FCC measure (step 7b) is the first cut if the window tightens. The cut is Kalli's to make. Session 13: zip 1 built and run (steps 4, 5, 6, 7a); zips 2 and 3 remain.

### Blocks delivery

| ID | One line |
| --- | --- |
| GJSON-1, D-157 | GJSON-1 still bounds any reader of the state outline; D-157's notes travel in the door's descriptions |
| SIZE-2 | broadband's counties copy is 8.6 MB (346,367 vertices, mostly coastline); Map Viewer draws it in the browser. If it loads slowly, `--tolerance 100` draws `..._web_100m` and `publish --display` points the map at it |
| MANIFEST-2 | sows reports available_but_missing for cii_2026_published and county_locations_2024; nothing in 8b read them. Read whether they predate session 2 |
| OUTCONF-1 | Before named outlets publish (counts already may): Kalli confirms the Claude-read reviews still in the seed (read_by): the Castine Patriot and the Boothbay Register placed by newsroom (Castine, Wiscasset count none of their own); whether the Peaks Islander still publishes; Gorham Times, Islesboro Island News, The Irregular, Maine Biz and Maine Wire placed by name. Cision's reads left with Cision (D-294). With the makers' word on Easton's and LNC's lists, named outlets move their tiers and terms (D-297, D-299) |
| WATERFRONT-1 | The Working Waterfront's reading (Rockland, where the Island Institute makes it) waits for a town review naming Rockland's code; until then it is listed no_town_given |
| TRIBE-10 | The clerk note is carrier_seen_on_nations_land (Kalli's draft); the state names two nations' offices as voting districts, and the 911 file spells Passamaquoddy as Pasamaquoddy: both shown only on the nations' terms |
| OWN-1, SRC-4 | OWN-1: ownership concentration exists (Kalli, session 12); confirm against the ledger's OWN-1 and close it. SRC-4 narrowed to named outlets (D-299, D-300): Jo Easton's and Local News Catalyst's word, asked in the wrap-up (to Molly Meller or with the professor's delivery package) |
| P-6 | The FCC benchmark, with 7b: 100/20 terrestrial is declared (D-271); the values wait |
| Tiers | Declared in session 16 for the outlet and clerk types (D-297); still none: outlet_disagreements and owner_crosswalk, with NOTE-3, D-173's review and TIERREAD-1 |
| FSCS-1 | A published library count's label: outlets of systems the survey does not count as public libraries |
| SCALE-1 | place.py writes "per 1,000" while the scale lives in the declaration |
| NAMES-1 | placed_by and review_read_by put a reviewer's name on every public clerk row; Kalli decides before handover |
| RECEIPT-1 | Rerun maine_counties, maine_county_units, maine_governance_units if profiles read them through $loam. |
| E911-1 | Publishing no longer waits on it (D-298); the courtesy ask to the GeoLibrary goes in the wrap-up package |
| TRIBE-7 | The notes' wording is drafted (D-233); it is shown as a draft until the nations' terms settle it, never withheld for want of them |

### After delivery

| ID | One line |
| --- | --- |
| OUT-REG-1 | stack_outlet_sources' registry entry names Maine's listings in a shared file; doing it right needs the orchestrator's input checks read (D-347) |
| RUNNAMES-1 | Two runs writing one receipt name, each receipt holding whichever ran last: maine_counties and maine_governance_units (validate_counties_checked, repair_counties_repaired, dissolve_counties_dissolved); nyc_thermal_landscape and nyc_park_cooling_pedestrian (validate_lst_checked, crop_lst_cropped). Named in tests/test_receipt_names.py |
| STEPNAME-1 | wonder composes a method's recipe step ids verbatim, so every experiment from cii_indicator_values writes standardize_standings; the step-name test holds the line until wonder prefixes them |
| DOORSAY-2 | After --replace finds an item gone, the plan line still names the step it first owed ("reseen"); restate the plan once the live check changes it |
| SIGNIN-1 | A refused sign-in in --check reads like a problem with the item, and a mistyped password moves on to the next item instead of asking again (seen 2026-11-18: two items read refused for a typo). Ask again for the same item, and say "the sign-in was refused, so this item was not read" |
| INDIAN-1 | 2300357936, Penobscot Indian Island Reservation's Census code in Aroostook, has a row (count 0) and no land face, so the outlet markers leave it undrawn and say "1 row outside"; how it is shown is the nation's to decide (P-8) |
| OAUTH-1 | An OAuth sign-in kind for ArcGIS Enterprise portals, where generateToken is no longer the default (D-329) |
| CATALOG-1 | The open catalog target kind (DCAT or STAC) for the open data hub, Sprint 13 (D-326) |
| O-6 | How a version is withdrawn: a person's own removal, a tombstone, a CloudFront invalidation, on the terms of the people the data describes. Until then the canonical write refuses custom tiers (D-315) |
| DEPLOY-1 | Retire the deployer IAM user's access key; deploy from expiring logins after |
| CANON-1 | The old outlets_* receipts (Cision in their lineage, 3) and the six receipts with no lineage sit in .data and .envelopes, withheld; D-373 retires them in 9b1's run, before the refusal record is written |
| BCAST-1 | A media database's radio and television stations count only where a local news list holds them; an FCC authority could say which air local news. Said in the method's interpretation |
| SRCFACT-2 | D-192 holds a run to one input's source facts; the outlet count's time is held to its five listings by a test until a many-input step can be held the same way |
| JOIN-1 | loam's join grammar knows a key's name, never its issuer; HRSA rows carry three issuers (BPHC, the grantee number, CMS's NPI). Nothing reads joinable() for carriers |
| GEO-2 | The Census Geocoder as second authority; the first read of the 74 misses leans against it (suites, highway names, suffix-less streets) |
| GEO-3 | D-237's GeoCode check needs a MEGIS GEOCODE to Census GEOID link; not built |
| ARC-1 | canopy/providers/arcgis.py pages by offset with no orderByFields and no held-still guard; off the clerk path since D-235 |
| KIT-2 | A shared points kit (member and encoding, state field, key, placed or listed, an issuer per key) was weighed and deferred: little gain before delivery, a retrofit's cost now |
| PLOT-2 | `city:` in preparations, manifests and sows' header ("City: Maine") should say plot: a schema key across the experiment and manifest schemas, every plot file and their readers |
| HRSA-1 | HRSA's metadata workbook is not read; the geocode's datum is unknown. HPSA, MUA/P, Health Sites and AHRF are catalogued in seeds/sources/hrsa.yml, unused; whether Health Sites sees the nations' clinics is unread |
| TRIBE-9 | The Census names 0115T "Aroostook Band of Micmac Trust Land"; as far as Claude knows the nation now calls itself the Mi'kmaq Nation. Verify, and decide on the nations' terms how a Census name and a nation's own name are shown |
| ACQ-7 | A url release declares its expected hash in source, and a fetch that does not match is refused; receipts already hash every input (md5, full_file), so a change... The rest of the line was lost in a broken paste; restate it from where it was defined |
| CHAIN-1, STAND-1, SCHEMA-1, SCHEMA-3, CHOICE-1, INTERP-1, QUADRAT-1 | As in the ledger |
| LIB-2, SERVES-1, OBS-1, P-3 | A second library authority; whom a carrier serves; our own observation of outlets; the free-outlet question |
| CON3-2, KIT-1 | Contract 3's wording; freshness never judges primitive code |
| P-8 | Section 203 on Wabanaki places, and what is shown on them: the nations' to decide, under CARE and OCAP. Never a deadline |
| P-2 | The pairing table: cited research, then Kalli's table; part 6 ships empty until then (D-285) |
| LIC-2 | The boundary layers' own item metadata (METWP24P, CNTY24P) is unread; D-290 rests on the statute and another GeoLibrary layer's credit line |
| GAPS-1 | Part 5's gaps in the method authors' own words, from readiness and possibility |
| PROF-1 | read_place loads the registry three times a call: most of a full build's five minutes |

### Sprint 09 (the explorer)

| ID | One line |
| --- | --- |
| CARRY-1 | loam's carriers view carries only id, name and coordinates. The door's points copies already carry every property, so the explorer may never need it: decide when the explorer's layers are drawn (D-347) |
| EDGE-NOTE-1 | located_in_edges receipts name no row notes, so rule 9 withholds the five carriers' edges; two lines in build_located_in and five reruns, only if the explorer needs carriers' edges in the bucket. Split towns do not: their shares are in every profile (corrected in session 1) |
| LENS-1 | Zip 9b2 (D-365, D-374): the two-pillar question is answered (CII places each indicator in exactly one). Still to read: seeds/indicators/language.yml and carriers.yml (directions, and where our own measures sit). Every values table is written canonically and joined before any lens exists |
| APPCHECK-1 | Zip 9b (D-366) |
| PLAINWORDS-1 | The state's withheld field is public and reads in working vocabulary: "Located in edges", "Outlet stack", and "it must carry a context note that it does not carry yet" (the gate's bookkeeping). Plain labels per kind of data in telling.py, then a new told copy and a move of both places maps. Small; before the app is featured |
| SIZE-3 | The places map is 3,995,923 bytes, 204,552 (5.4%) more than session 4's shapes map; the state's row explains a few KB. Compare the two maps layer by layer before LIMIT-1's line is set |
| PROFTIME-1 | The profile stamps `built_at` into every place, so a rebuild with identical places is a new version (D-382). Whether the time belongs outside the hashed bytes, as D-322's spirit asks. After delivery |
| LIMIT-1 | ITEM_BYTES = 4,000,000 still names no source, and the explorer's places map is 3,995,923 bytes, 4,077 under it: any growth in the told text (PLAINWORDS-1, 9b2's fields) may cross it. The door reports the map's size and applies no line. Set the line from Maine's own broadband data (how long the explorer takes to load at the worst-served fifth), not the portal's ceiling: about 32 megabits, roughly 1.3 s at 25 Mbps and 32 s at 1 Mbps, before Experience Builder's own load |
| HUB-1 | The Hub site (pressforwardmaine-nu.hub.arcgis.com): its owner, before the app is featured there |
| DEMO-2 | demo/index.html shows an old console run of `map maine indicator_standings --layer units_geoid_with_geoid`, a receipt D-373 retires; the demo is reread after delivery |

### Not yet sorted (look each up in the ledger)

S2-1, GATE-2, GATE-3, MAP-8, MAP-9, TRIBE-4, SEN-1, LEGI-1, LEG-4, LIC-1, KEY-1, XCHK-1, COMP-1, REG-1, LOOP-1, ACQ-6, SCH-5, TAG-1, MEGIS-3, LURC-1, BAXTER-1, DISS-1, METH-1, LIN-2, VER-1, NOTE-2, TRIBE-5, PENOB-1, RESOLVE-1, SEAM-2, DAS-1, HIST-1, SRC-3, USE-1, SPEC-1, COUNT-1, TENURE-1, TRIBE-6, LEDGER-1 to LEDGER-3, ROLE-1, the draft notes. TRIBE-4 and SEN-1 are dated (2026-12-02) and block maine_seats.

Closed in session 8: SURVEY-1 (D-231), LOAM-2 and TRIBE-8 (D-233). Opened: CARRY-1, KIT-2, PLOT-2, HRSA-1, TRIBE-9; ACQ-7 carried in from an uncommitted ledger line.

Closed in session 9: GEO-1 (D-234 to D-239), TOWN-OFF-1 (D-236). Opened: E911-1, GEO-2, GEO-3, GEO-4, ARC-1, TRIBE-10.

Closed in session 10: GEO-4 (D-240), WHERE-1 (D-241, reopened and settled by D-242 to D-246). Opened: MEDIUM-1, OFFTOWN-1, OUTREV-1, UNDATED-1.

Closed in session 11: MEDIUM-1 (D-247, D-248), OFFTOWN-1 (D-250), UNDATED-1 (D-252). Opened: EDITION-1, BCAST-1, SRCFACT-2. OUTREV-1 carried with its queue.

Closed in session 12: EDITION-1 (D-255), OUTREV-1 (D-253 to D-257, the reviews seed). Opened: OUTCONF-1.

Closed in session 13: P-7 (D-265). KEY-1 now carries the key's replacement.

Closed in session 14: P-1, P-5 (D-271).

Closed in Sprint 08 session 1: CLIDOC-1, ADOPT-1 (the door made its own item), O-4 (D-327), O-5 (D-328), F1, F2, F4, F5, F6 in the shape the door has (D-326 to D-333; the joined copies' counts with D-331). Opened: OAUTH-1, CATALOG-1, NAMES-1, DOORSAY-1, DOORCHECK-1.

Closed in session 15: the boundaries' terms (D-290), the counts' rule 9 gap (D-291); Tiers in part (D-283). Opened: LIC-2, GAPS-1, EDGE-NOTE-1, NOTHR-1, PROF-1.

Sprint 09 sessions 2 and 3: the four forks settled (D-363 to D-366); opened EXPLORE-1, LIMIT-1, STACK-1, SHARES-1, HUB-1.

Sprint 09 session 4: D-367 to D-375; WITHHELD-1's read done (D-373); LENS-1's two-pillar question answered (D-374). Opened WTABLE-1, DEMO-2, ROUND-2.

Sprint 09 session 5: D-376 to D-382. Closed EXPLORE-1, STACK-1, SHARES-1 (R5), WTABLE-1 (D-376), ROUND-2 (D-379), PLACES-1 and WITHHELD-1 (zip 9b1 run). Opened PLAINWORDS-1, SIZE-3, PROFTIME-1.

Closed in Sprint 08 session 2: LAYER-1 (D-338), DOORSAY-1, DOORCHECK-1 (D-345), DEPS-1, NOTHR-1. Opened: RAMP-1, UPDATE-1, SIZE-2, MANIFEST-2, RUNNAMES-1, STEPNAME-1, DOORSAY-2, SIGNIN-1, INDIAN-1.

## How files move (the zip workflow)

The one home for how files travel between Claude's sandbox and Kalli's machine (Kalli, Sprint 09 session 3, written out so it cannot drift). The repo is public, so nothing is ever written to the repo root that is not meant to be committed. Every path below is repo-relative, and every command runs from the repo root.

**1. Reads: Kalli's files to Claude.** Claude never guesses a file name. It gives one block that builds the list from the repo itself (`find`, `git ls-files | grep -E`, `git --no-pager grep -l`), sorted and deduplicated into /tmp/<name>.txt; a second block prints the count and the list, so Kalli sees what goes; a third zips exactly that list:

    zip -q ~/Downloads/<name>.zip -@ < /tmp/<name>.txt && ls -lh ~/Downloads/<name>.zip

Reads zips are named for the session and step, in order: reads_9b, reads_9c, reads_9d. They go to ~/Downloads, never the repo root (session 10's two context zips and session 3's reads_9c.zip sat untracked there). Kalli attaches the zip to her next message. A count far off what Claude expected is pasted before the zip is made.

**2. Changes: Claude's files to Kalli.** A build, a fix or a hand-off comes as one zip of repo-relative paths, made in the sandbox and listed with `unzip -l` before it is delivered, with no `__pycache__` or other strays in it. Kalli downloads it to ~/Downloads and unzips it from the repo root:

    unzip -o ~/Downloads/<name>.zip -d .

Files are whole-file replacements, never positional patches. `git --no-pager diff --stat` and `git status -sb` are read before anything runs, and Claude says what they should show. A file Claude has not seen whole is changed by a guarded helper in _sprint06/ that writes nothing unless its anchor matches exactly once; _sprint06/ holds helpers only and is deleted at the session's end. Inline `cat > path << 'EOF'` is for one small file when a zip would be heavier: one file per paste, every `EOF` at the left edge, the path read in the diff-stat before it is trusted (session 10 once wrote state.md to a root file named PATH). A long paste runs alone.

**3. A ledger block travels inside the zip, never into the repo.** It sits at the zip's top level as ledger_block_<sprint>_<sessions>.md, starting with a newline. The repo files are unzipped without it, and it is appended only when its heading is absent, in one command so it can never land twice (5aacc14):

    unzip -o ~/Downloads/<name>.zip -x <block>.md -d .
    grep -q "<the block's heading>" field-guide/docs/build_ledger.md && echo "already there" || unzip -p ~/Downloads/<name>.zip <block>.md >> field-guide/docs/build_ledger.md

Every new decision and item ID is grepped with `grep -n` before the append (`|| echo "none taken"`), since a block's own line satisfies a later grep.

**4. Rehearsals are evidence, and they live with the tests.** A rehearsal script lives at tests/rehearsals/<sprint>/, beside tests/debug/, with the record of what it sent, and is committed (Kalli, session 3). Session 2's rehearse_places.py sat in _sprint06/ and was deleted with it. A rehearsal and a test differ in one way: a rehearsal reaches the live portal with a typed password and is run by hand; a test runs offline, every time, in the suite. pytest collects only test_*.py, so a file named rehearse_*.py or diff_*.py never runs in the suite; `python -m pytest --co -q tests/rehearsals` says so. What a rehearsal finds becomes a test: the portal's behaviour goes into the door's fake portal, the way it already rewrites descriptions as ArcGIS does (D-349), so the suite guards it from then on.

**5. Every commit is guarded and names its files.** A zsh array, then add, a check that prints STOP when nothing changed, and a commit that keeps everything else out:

    files=(<path> <path> ...)
    git add -- $files && { git diff --cached --quiet -- $files && echo STOP || git commit -m "<message>" -- $files; }
    git push && git log --oneline -3 && git status -sb

**6. The hand-off.** It ends with one zip, <sprint>_handoff.zip: field-guide/docs/state.md, the ledger block, and anything else the hand-off commits. Kalli runs it through steps 2, 3 and 5. The next session starts when Kalli uploads that same zip; Claude reads field-guide/docs/state.md inside it whole, the retrospectives first, before anything else.

**7. Loose downloads.** A file Claude delivered loose and then replaced with a zip is removed from ~/Downloads with `rm -f` before the zip is unzipped, so an old copy is never moved in by mistake.

## Working agreement, as it stands

- Never build against a schema or part of the codebase not yet read (Kalli, session 13): before any code, Claude lists every contract it must satisfy (envelope and metadata schemas, method, experiment and manifest schemas, registries, the readers downstream of what it writes), reads each as it is in the repo, reads every test and caller of what it changes, and says in the consultation what it read and what it could not see.
- Design before code, nothing chosen silently. Small choices: Claude takes the lean and says so.
- How files move between Claude and Kalli's machine has one home: How files move, above. Every other line here points to it.
- Sessions are consultations for a zip (Kalli, session 12): a short consultation per step (what the zip holds, forks with leans, what only Kalli or her machine supplies), then one ambitious zip that builds it all on her go. A zip can hold any amount of code; it cannot hold data her machine must fetch, her decisions, or terms not yet read, and each consultation names those three.
- Claude may read public sources and draft reviews from them (session 12): each cites the page read, read_by says Claude read it, and Kalli confirms before publishing. Claude's guesses are never evidence; a page read and cited is.
- Four forks to a decision tree (Kalli, session 10): Claude reads what the forks rest on first, lays out the tree with a lean, the problems and how to make each better, workshops it with what the reads show, then drafts one holistic zip that fixes everything found, on Kalli's go. A fork that rests on data waits for its read. The guards stay: diff-stat counts, guarded helpers, a receipt read after every real run.
- Questions only when the build needs the answer (Kalli, session 10).
- Until the product is delivered (Kalli, session 7): Claude drafts all code, primitives included, as zips, once Kalli says go. Kalli drives the terminal herself to learn it: unzip, helpers, diffs, tests, dry runs, runs, receipt reads, guarded commits, push, each command explained in plain words. After delivery she returns to writing code.
- Diagrams carry description and fun metaphors; responses stay readable, short sections (Kalli, session 7).
- A fork lists only options that could win. An option already refused, or one nobody would choose, is not listed (Kalli, session 5).
- Go in the plan's order unless Kalli says otherwise.
- Drift is fixed when it is found, never deferred to a later fork (Kalli, session 2). When one truth is written in several places, it gets one home and the others point to it.
- Everything in seeds/ is shared by every plot: reusable, never tailored to one project, possibly international someday. Domain logic gets no top-level seeds/ folder of its own (Kalli, session 2).
- A type is declared before anything names it, and a declaration names a current type (D-220). The walks in tests/test_current_type_names.py hold every plot to this, so drift fails a test instead of hiding.
- Rule or choice: ask whether a reasonable person could decide it the other way. No: a rule, held by a test. Yes: a choice, declared in the method and recorded in the receipt.
- Before any threshold or external claim, Claude researches and cites what a source actually says, in the vintage the build uses, and says plainly where a source gives no number.
- When Kalli says a concept is unclear, Claude explains it from the ground up, with a picture where one helps, before asking anything of it.
- Grep every new ID before it is written anywhere. No em dashes, no inline shell comments.
- Before changing a signature, search the keyword across every caller and test, then read each hit for meaning.
- Read real output as its reader would before committing a telling. A receipt is read after every real run.
- Usage: one step per chat; long output is filtered (`| tail -3`, `| grep`); Claude names exact files and asks for whole files rather than many line ranges. What is uploaded, and how: How files move.
- A data check is a "read", never a "probe" (Kalli, session 8).
- A test that stubs a contract (`validate=lambda e: []`) has not read it: the joined copy passed every sandbox test and failed the real schema (session 2). Every schema a new output meets is read whole, and one test holds the new output to it unstubbed.
- The ID grep comes before the append, and reads lines with `grep -n`, never only a count: a block's own line satisfies a later `grep -c` (session 2).
- Run `publish <plot> --check` before committing a publish run's record, and after anything is done by hand in ArcGIS.
- At a fork, Claude's preferred option is an intuition, not a lean (Kalli, Sprint 09). When Kalli says go with the intuitions, Claude revises each once against failure and drift before it is recorded.
- A rehearsal script lives in the repo at tests/rehearsals/<sprint>/ with the record of what it sent, and is committed at the hand-off. Session 2's rehearse_places.py sat in _sprint06/, which is deleted at a session's end, and no copy survived.

## Traps

- /mnt/project in Claude's sandbox is a partial snapshot, refreshed 2026-11-13 before session 4's edits; some files in it are empty and others are missing. The repo is on Kalli's machine, and a file to be edited is read from her copy or changed by an anchored helper.
- Run everything from the repo root. An unzip from field-guide/docs once made second copies of soil/ and tests/ there, and pytest refused the duplicate test names.
- Run a preparation with `python -m canopy.cli sows <run.yml>`; `--dry-run` only validates. `sows` prints nothing until the run ends. Never `--resolve-only` casually (RESOLVE-1).
- Do not run maine_seats on real data before 2026-12-02.
- A canonical write is public and permanent. Dry-run it, write one artifact, then read the pointer with curl and the data with DuckDB, using the two commands the write prints.
- Output saved to a file is buffered while errors are not, so a traceback can sit far above where a run died, and `tail -1` shows the last line printed. canonical --all prints line by line; other commands may not.
- In ArcGIS Online, adding a GeoJSON through Content, New item, imports it: an uploaded copy, a hosted feature layer offered. A display copy goes in through Map Viewer's Add layer from URL and is saved in a web map (D-325).
- A curl -sI answer names no URL: the URL is the one given to curl, and the one the display write prints.
- A block Claude draws that is not a command is drawn so it cannot run. One pasted diagram reached zsh in session 2 and was refused whole, harmlessly.
- `authority` means only who assigns a place's code; a publisher is `published_by` everywhere, manifests included.
- `$indicators.<id>` resolves to the declaration as a primitive receives it (as_declaration), with declaration_sha256 taken over the indicator's own mapping without its rationale (D-227). Adding or editing a sibling, a comment or a rationale moves no receipt; editing source, weight_by, replicates or the derivation does, and so does moving the indicator to another file (declared_in). as_declaration omits source, weight_by, replicates and rationale: the hash is what lets freshness see the first three.
- A preparation uses soil/ primitives only and a preparation method; a run with a roots/ step or an analysis method is an experiment and names its curiosity (D-98, D-228). `curiosity: ref: ""` is a warning, never a pass.
- Two functions are named read_envelope: canopy.envelope.read_envelope returns an Envelope object (what freshness's judge reads); canopy/loam/envelope_reader.read_envelope returns a dict and needs a vocabulary.
- Origin can move between sessions (session 6: four commits by other authors). Before pushing, `git fetch` and read `git --no-pager log --format='%h %an %ad %s' --date=short main..origin/main` and `git --no-pager diff --stat main...origin/main`; rebase only after reading them. Never `git add .`: in session 6 it committed a stray environment.yml edit under another commit's message.
- The indicator registry globs every seeds/indicators/*.yml as indicator declarations, names flat and global across files (registry.py, line 199). Put nothing else in that folder.
- A run's `$choices.<name>` reaches a step as the raw value. A choice outside its method's options only warns (CHOICE-1), so a primitive that depends on one refuses a bad value itself.
- A step's outputs are `name: type`; the type is a current semantic type, never `<thing>_validated` or `_checked` (D-220). Validating or reprojecting keeps the input's type. The experiment schema's example now says so.
- Vocabulary.get_tier reads `tier`, not `resolution_tier` (TIERREAD-1): do not rely on it for a type's exposure tier.
- `imls_pls_fy2024_outlets` is a located_in layer label set in maine_libraries, not a manifest dataset or a type. The indicator names `counts: library_outlet` (D-224); a `layer` key in an indicator seed is refused by name. The label reaches the receipt as count_located's counted_layer.
- IMLS's outlet types and structure statuses live in seeds/crosswalks/libraries/imls_pls_outlets.yml (D-226). A plot never declares them; a release's member and encoding go in its manifest entry under `source:` (outlet_member, outlet_encoding), and the run's copy must agree (D-192).
- seeds/sources/ is read by no code, by design (D-226): a catalogue there is reference only, and a test holds that imls_pls.yml's pointers exist.
- The carriers view needs each carrier's points file to carry its receipt's id_field and a `name` property, and finds the points through the edges receipt's own provenance record (the newest without lineage_branch). A new carrier preparation writes both (D-225). A carrier placed by town (outlets) is a table, and the view leaves it out by name (D-246).
- pandas reserves `.flags` on a Series and a DataFrame: a column named flags is read by key, `row["flags"]`, never as an attribute.
- group_outlet_records numbers groups by row order (g0001...): a group id is never an identity. Outlets are keyed by their members (D-243), reviews by source and name as written.
- The outlet stack, groups and outlets are CSV in plots/maine/.data; the edges and counts are parquet. maine_outlets and maine_outlet_carriers each stack and group under their own step ids.
- outlet_sources.yml changed in session 10 (source_order, operating_vocabulary), so maine_outlets' own receipts read stale until it is rerun; nothing reads them.
- place.py reads indicators through IndicatorRegistry: a root with no seeds/indicators refuses, where the old raw-YAML walk returned nothing in silence.
- `git grep` and `git diff` open a pager that can cut output at "...skipping...": use `git --no-pager grep` and `git --no-pager diff`.
- A method is read only through parsing.load_method_data (D-213). Options are a mapping keyed by option id (an empty value allowed), requires_primitives a list of layer/name, produces a list; a field the schema does not describe is refused. canopy/wonder still reads methods raw (SCHEMA-3). A method's name lives in the method, never the index (D-216).
- `git rm` stages a deletion; a later `git add` naming that path fails the whole add and stages nothing. Name an already-deleted path in `git commit -- ...` only.
- `| tail -3` prints nothing until pytest ends, about two minutes for the full suite; the terminal is not frozen.
- Claude's sandbox shell is dash: no brace expansion, so `mkdir a/{b,c}` makes one literal folder and once shipped it in a zip. Claude uses `bash -c` or one path per argument.
- loam's `edges` view is made from exactly one `place_edges` artifact (D-163); never write a second. Point edges are `located_in_edges` (D-207).
- loam's place_values attaches a value only when seeds/vintages/boundaries.yml holds a rule for its `published_by`; it reads the ACS's `levels` for every publisher (LOAM-2).
- The 2024 faces are a zip of county zips (plots/maine/.data/maine_faces_2024.zip); build_block_spine reads their .dbf only, build_located_in their geometry.
- The IMLS outlet file is Windows-1252: declared, never sniffed. A pandas read that falls back silently would have written a control character into two names.
- The FY 2024 outlet file holds no STATSTRU 03: permanent closures are listed outside it (its documentation's Appendix C). Older files kept such records.
- `grep -c` counts lines, and a GeoJSON file is one line: a 1 means at least one match. Read features with python, never by counting.
- A test loading a soil module by file path must register it in sys.modules before exec when the module defines a dataclass.
- The envelope schema checks metadata types (a point layer's total_area_m2 is 0.0, never null); fixture tests do not see this (SCHEMA-1).
- MEGIS Maine Town Points (METWP24PT) are town centroids, not offices: refused as a carrier layer.
- Freshness never judges primitive code (KIT-1), and is judged only when a run reaches a `$loam.` input. The read-only probe: build an Orchestrator on any Maine preparation, then `judge(read_envelope(p), orch.project_root, orch._declared_params)` for each file in plots/maine/.envelopes.
- `wonder --place` takes a key, AUTHORITY:CODE, never a name. A town range is one estimate per town; read the firm range before quoting a range's ends. A carrier has no range.
- A step's `outputs:` gives names, not paths. Receipts are `.envelopes/<step>_<o>.envelope.json`.
- The geography graph preparation declares `vintages` twice; change both together (D-162).
- Scope every grep: quote globs, and never grep `plots` without `--include="*.yml"`. `git diff` opens a pager; use `git --no-pager diff`. It is `git status -sb`, one dash.
- Keys live in Kalli's environment only (KEY-1). The repo is public. garden/reference/ and **/.data/ are ignored; commercial listings never leave them.
- The sandbox lacks pytest, pyarrow, shapely, geopandas, duckdb, jsonschema, pyogrio and R; it has pandas and yaml. A small stand-in for pytest.raises lets pure-pandas tests run there.
- NCES EDGE's text table has no header row; its 23 columns come from the crosswalk, and a field holding a pipe is quoted: read it with a quote-aware reader, never `split("|")`.
- Three state fields in EDGE mean three things: STATE the reported address, STFIP where NCES's point stands, OPSTFIPS who administers the school (59 BIE, 63 DoDEA). Place by STFIP (D-230).
- A located_in edge's `to_authority` is not its level: us_census_geoid holds state (2 digits), county (5) and town (10). A per-drawer check groups by authority and code length; by authority alone it reads 3 for one card per drawer.
- A dashboard export (Maine DOE) is not a release: a fresh export is a new source, and only our copy is evidence. Its file name's number is the export time in milliseconds since 1970, UTC.
- `loam`'s `joinable()` relates holdings by key name, so every carrier's feature_id looks joinable to every other (JOIN-1).
- A count's boundaries are boundary_vintage, never its time (D-231): write `time` as what the source describes (FY 2024, SY 2024-25, a snapshot's day).
- HRSA's three state fields: Site State Abbreviation (the site), State FIPS Code, Health Center Organization State (the grantee's office, never where a site stands). Rows HRSA holds with no site state read XX, with no point.
- The spine stores a tribal area as AIANNH (four digits) plus aiannh_comptyp (R, T); a place's code is the two joined (2760R). Group by the bare code and a reservation merges with its trust land.
- A count_located step at the aiannh level must name tribal_note; tests/test_tribal_counts.py walks every plot.
- `Data Warehouse Record Create Date` is the day of HRSA's copy, not of any site.
- The loam carriers view does not carry point properties beyond id, name and coordinates (CARRY-1).
- The ledger is field-guide/docs/build_ledger.md, underscore. A grep on a misspelled path prints nothing, exactly like a clean grep.
- The 911 FGDB and the live FeatureServer are not one dataset: 798,422 points against 801,786, older field names (STREETNAME, SUFFIX) against NENA's (ST_FULLNAME). Only the file is read.
- PLACE_TYPE in the 911 file defaults to Residential and is set town by town: never evidence of a use. Government - Municipal holds salt sheds and a snowmobile club.
- The Secretary of State's clerk CSV names five columns twice; pandas renames the second copies (.1). The primitive reads by position with the csv module.
- pyogrio opens the .gdb.zip directly; leave the zip whole, it is the evidence.
- The clerk list's GeoCode means the row's own town on most rows and its serving town on three; it is blank on 17.
- pandas 3 reads a column of text and blanks as str, and Series.map over it turns a returned None back into NaN: never test a mapped Series value with `is None`. Judge each value with _text, one at a time. A test that hands a table from one step to the next in memory never sees this; round-trip it through the csv the run writes.
- Cision's ZIPs lost their leading zero in a spreadsheet (Maine's 04282 reads 4282) on some rows; compare ZIPs as five digits, and never take the first five digits of a stripped ZIP+4.
- The carriers' own stack and groups are carriers_stack_stack.csv and carriers_groups_groups.csv: a glob for *outlet* misses them and finds maine_outlets' stale copies (926 records either way; session 10's 924 was a miscount).
- Session 10's hand-off wrote state.md to a root file named PATH: a heredoc's path is read in the diff-stat before it is trusted.
- _sprint06/ holds read helpers only; delete it at the session's end, never commit it. A rehearsal is not a read helper: it goes in tests/rehearsals/ (session 3).
- Listed outlets live in the receipt (metadata.listed_outlets), never the csv, which holds placed outlets only. Session 12's first read helper looked in the csv and read "absent" for "listed".
- A read of the outlet csv taken before a sows run reads the old run: the review checker's watch list did, and showed the Boothbay paper twice after it was merged.
- A review names a record by source and name as written; a name a source writes twice alike (same_record_as) is named once, and a name the run shows is its first member's by source_order (local_news_catalyst, then maine_media_ecosystem, before cision).

- Every receipt's metadata carries crs (null for a table): the envelope schema requires it, and fixture tests never see it (SCHEMA-1).
- R's derive_indicator grows `needed` with the rests_on cells partway through its loop: a count's margin and emptiness read the count's own cells only.
- Section 203's town rows write county 000: towns join by the five-digit MCD; its map is 2019-era, so towns since deorganized appear under old codes.
- The Skills Map file writes Lit_P1, not LIT_P1; its State sheet carries fewer flag columns than its County sheet.
- acs_state_2024 and acs_state_2024_language hold all 52 states: the API's state level cannot be narrowed; only Maine's row attaches.
- macOS sed edits in place with `sed -i ''`.
- A receipt is named for its step and output (`county_language_derive_values`), never its type: find receipts by the semantic_type inside them, never by a pattern on the type's name (session 14's first find missed ten).
- Claude's sandbox python glob skips dot folders: `glob('**/*.json')` never sees `.envelopes`. Glob inside the folder.
- `left_out` meant three things before D-278: towns out of a range (place.py), receipts out of a view (graph.py's report) and people short of a line (literacy). Read which before using the word.
- CII's literacy is an average score; PIAAC's is a share at or below Level 1. Same subject, different measures (D-282).
- loam views only indicator_values; literacy_estimates and section203_records have no view until D-275 is built.
- A shell export pasted across two lines exports a different name: check with `python -c "import os; print(bool(os.environ.get('CENSUS_API_KEY')))"`.

- A declared outlet source is left out of a run by stack_outlet_sources' use, never by dropping its input: the stack refuses a used source with no input and an input it does not use (D-294). maine_outlets still stacks all five and is stale; nothing reads it.
- `"cision"` in a carriers receipt is expected: the shared declaration rides in as params and the stack warns which declared sources it left out. Read input types and data_resolution for lineage, never a text search.
- A merge needed only because one source held a record twice refuses as no longer needed once that source leaves (D-240): remove it then, never before.
- The profile command prints its progress to stderr and its summary to stdout; `> file` keeps only the summary. `--place` prints one profile's JSON and writes nothing.
- The gate reads the manifest's licenses at judging time: a license change needs no rerun; a receipt's own metadata does.
- A level outside Contract 4 is profiled with place.level_note (D-292); a test counting profiles counts every level.
- A receipt is named `<step>_<output>` in one .envelopes per plot, and a harvest by its receipt forever (D-318): two runs sharing a step id and output overwrite one receipt, and the next canonical write would move a harvest to the other run's table. tests/test_receipt_names.py names the known pairs (RUNNAMES-1).
- A validate step passes its input through: its receipt's data file is the fetched source (validate_counties_checked is MEGIS's own layer), and the canonical write refuses it (D-337).
- ArcGIS Online rewrites an item's description as it saves it (`&#x27;` becomes `'`): compare what the portal stores, never the hash of what was sent (D-349).
- A door item's id is what a web app holds. Deleting one in ArcGIS and remaking it with --replace gives a new id; anything built on the old id breaks.
- A recorded console transcript (demo/index.html's figures) is history: never rename a line inside one.
- After a renamed run, move its old receipts out of .envelopes (into .data/retired): loam unions every receipt there, and the old and new would carry one indicator twice.
- `--local` copies need no AWS; every other `--display` needs the writer profile, even as a dry run.
- In Experience Builder, a widget that should follow a search connects to the Search widget's output data source (Select data, Outputs tab), never the searched data; wired to the searched data it never changes (session 1 lost a morning to it).
- A test page that may refuse to be framed (example.org) is no test of an Embed; OpenStreetMap's embed pages are made to be framed.
- A shapely LinearRing has no area: measure a hole as shapely.Polygon(ring.coords).
- Every door write changes plots/maine/publish/published.yml, the door's record of what it made. Commit it with the run, every time: after the restyles it sat uncommitted until `git status` showed it at the hand-off.
- A check and the step it guards are one command, never two pasted lines with "skip the second": `grep -q "<heading>" <ledger> || cat <block> >> <ledger>` appends only when the block is absent. Two lines pasted together appended the run's block twice (5aacc14, undone in 5e8c969).
- Claude's sandbox has no shapely, geopandas, duckdb or pytest, so it runs pure-Python tests through a stand-in and skips the rest; tests that need shapely run first on Kalli's machine.
- ArcGIS stores a whole float as an integer (5615270.0 comes back 5615270): a hash of the sent text never matches the stored one unless whole floats are written as integers first (D-362).
- The door's arcgis_webmap kind is built around one layer that reads a URL: build makes one layer, moved reads operationalLayers[0], layer_url and adoptable_layer key on `url`. A feature collection layer has no URL, so any check that compares URLs judges it wrong without crashing (D-364).
- Run a rehearsal from the repo root: `python tests/rehearsals/sprint-09/rehearse_places_webmap.py` (dry run; `--write`, `--check`). It reads only the bucket, through CloudFront, and needs no AWS credentials.
- The polygon read: `python -u tests/rehearsals/sprint-09/rehearse_places_webmap.py --polygons --tolerances 25,100,250,500 --decimals 0,1 --polygon-levels cousub 2>&1 | tee /tmp/<n>.txt`, then copy the output into tests/rehearsals/sprint-09/ (it is evidence, and /tmp empties). `-u` matters: piped output is buffered. `--polygons --write` sends one map and refuses while places_polygons_sent.json exists; `--polygons --check` reads it back.
- Validity is read at every stage a shape passes: the outline, the simplified shape, the rounded rings. Session 4's first read labelled its failures by the stage it checked last; only the three-stage read laid them at the rounding. One flawed border shows up in every level that shares it (the same point near Lewiston in a county, two districts and a town).
- Esri JSON winds an outer ring clockwise and a hole counterclockwise, the opposite of GeoJSON (RFC 7946). A ring written the GeoJSON way can read a hole as land.
- The profiles' working text carries ledger ids by the thousand (D-271 alone 18,293 times); nothing public may pass it through. The telling builds from structured fields.

## People

Kalli delivers the whole product: every sprint, the publish route (Sprint 08) and the infrastructure (Sprints 07 and 10) included. The people once named here work on other things (Kalli, session 5). bash-win and Jessica Pham are helpers Kalli recruited, who join her weekly lab sessions; their commits on 2026-11-14 brought staging Terraform, API load tests and plot locks, the Docker image and NYC fetch dates. DEPS-1 likely came with their locust tests (7afefd1); whether DEPS-1, KIT-1 or OUT-REG-1 move to them is Kalli's to say, and until she does they stay hers. Items that were theirs are hers now: LAYER-1, GJSON-1 and D-157's required notes argument for the publish door; DEPS-1, KIT-1 and OUT-REG-1 for the Docker build; the tier declarations, note wording, NOTE-3 and D-173's review. P-8 and TRIBE-7's wording wait on the Wabanaki nations' terms (open items).

## Starting the next session

Kalli uploads this hand-off's zip (s09_s5_handoff.zip). Claude reads field-guide/docs/state.md inside it whole, the retrospectives first, confirms, and asks for what the next step's design needs. Files move as How files move says. Ask whether the repo is current (this hand-off's commit at HEAD, clean, pushed). A zip Claude makes may land wherever Kalli's browser last saved, twice this session inside canopy/: find it with `find . ~/Downloads -maxdepth 3 -name "<zip>"` and move it out of the repo before unzipping.

**Next: zip 9b2's consultation** (the Master Plan's Sprint 09 tab; D-375). Sprint 09 is done when someone who has never seen the project can find their town, learn its barriers and carriers, and see what the tool cannot yet answer. The places map is public; 9b2 makes the rest.

1. **9b2's reads, named before any design:** seeds/indicators/language.yml and carriers.yml (the crosswalk's placements, D-374); the values tables' receipts and their joins (canopy/aws/display.py's draw_joined); canopy/expose/targets/arcgis_webmap.py and arcgis_places.py (lens maps beside the places map); canopy/expose/publish.py (`--adopt-app`, D-366); tests/test_places_map.py's fakes.
2. **9b2's consultation:** what the zip holds, about four forks with intuitions, and the three things a zip cannot hold.
3. **PLAINWORDS-1**, small, can ride with 9b2: plain labels for the withheld field, then the told copy and both places maps moved. Watch LIMIT-1's 4,077 bytes of headroom.
4. **9b2's build and run**, then the app built by hand in Experience Builder from the guide, and `--adopt-app`.

After 9b2: Sprint 09's progress report, the Master Plan's stale "Where it stands" and Sprint 09 tab (its forks are D-350, D-361 and D-375 now), and the delivery blockers before handover (NAMES-1, OUTCONF-1 and the rest under Blocks delivery).

## Sprint 09 session 5's notes (R5, 9b1 built and run, the explorer's places public)

- What went right: every write had a dry run first and every dry run had a prediction, so the two surprises were caught before anything permanent: the profile's hash moved on rebuild (read to the cause, a clock in the bytes, D-382), and the refusal record counted the write's own refusals as the gate's, which would have told the public that the towns themselves were withheld (fixed in 9b1a before the record was written). The spec read settled WTABLE-1 without a rehearsal. Every count matched D-373's prediction before the move.
- Wrong hypotheses: that the refusal record could be the gate's judgment alone (the write refuses some receipts before the gate is asked, and the gate refuses them too); that a profile rebuild repeats its version (it stamps a time); that the places map would be within a few percent of session 4's (it is 5.4% larger, SIZE-3); that this chat had to be fresh for 9b1 (it was already fresh after session 4).
- Lessons: a refusal belongs to whoever refused first, so a record of the gate's refusals must ask the write's own checks before it tells anything; a document that stamps its build time cannot be checked by its hash across rebuilds, only by its content with the time set aside; read words that leave in public before they leave, not after (PLAINWORDS-1 was read after the explorer write); a sandbox without the suite's libraries runs a stand-in harness, which says less than the real suite, so the real suite runs first in every run.
- Session shape: one chat held R5's results, the spec read, two reads zips (reads_9g, 38 files; reads_9h, 28), 9b1's consultation, its build (24 files), 9b1a (6 files), the whole run to the public explorer, and this hand-off.

## Sprint 09 session 4's notes (the polygon read, the shapes map, 9b designed)

- What went right: the shapes question was read before it was decided, three ways (bytes, parts and area, validity at three stages); every prediction was made before its run and checked after (the points map's sha after a refactor, the byte counts, the mixed map's size); the evidence was copied out of /tmp before anything else; the write printed what it would send before it asked for a password; the stored map matched the sent one exactly, which proved D-362 at the moment of sending.
- Wrong hypotheses: that islands would lose parts at coarse tolerances (none did; they shrink, Muscle Ridge Islands to 56.6% of its area at 500 m); that the first read's "made invalid by the rounding" was earned (it was right, but unproven until validity was read before rounding too); that the five recorded entries needed their kind written (they already named it); that _sprint08/ held only helpers (it held run_8b.md, deleted with it); that the door could carry the places map as a flag (it reads one parquet parent; the profile is a document).
- Lessons: read a shape's validity at every stage it passes, or a failure is laid at the wrong step; a border's flaw appears in every level that shares it; name a derived copy by every input that can change it, not only its parent, or a changed seed means new bytes under an old name; a folder named for helpers is read before it is deleted; the weight of the explorer is a digital-access barrier of its own, so the text, not the shapes, is where size is saved (2.35 of 3.79 MB).
- Session shape: one chat held the repo check, two reads zips, three rehearsal zips, two polygon reads, the shapes map's write and check, 9b's consultation and this hand-off. The hand-off rule stands: zip 9b1 starts fresh from this page.

## Sprint 09 sessions 2 and 3's notes (the reads, two rehearsals, the forks settled)

- Session 2's reads (reads_9b, 74 files; canonical maine --all; three receipt reads): the 21 withheld are rule 5 outlet types (3), rule 9 tribal edges (5), rules 5 and 10 on the stale outlets_* (3), rule 4 with no lineage (6, not eight), and four the canonical write refuses (literacy and Section 203 as CSV, validate_counties and validate_towns as fetched sources, D-337), whose content reaches the public another way. The profile's receipts_withheld and structure_withheld are empty. outline_state_outline may leave and was never written; GJSON-1 does not bind the canonical path. The values tables (towns, House, Senate: broadband standing, no vehicle, rent burden, households without broadband, limited English; counties: rent burden, no vehicle; the state: the count) are not in the bucket. A canonical refusal record cannot pass today's gate as an artifact (rules 4 and 10): refusals are content, like the allow record.
- Session 2's rehearsal: a Feature Collection item of the towns' told rows (528 placed; 2300357936 left out, not invented) stored parsed identical; Search, Text and Table worked; the Map widget takes only web maps, and Map Viewer saved a web map of it with empty operationalLayers. Both items were found public though made private.
- Session 3's rehearsal (tests/rehearsals/sprint-09/): the profile and five outlines read through CloudFront, each checked against its sha256; each place's point is display.py's marker, projected with the door's _mercator. The dry run met every prediction: 16, 35, 151, 528 and 8 placed; the state and 2300357936 left out and named; 2,351,368 bytes. Sent private to test as 000c5dcf102f4b878562a0494b6ee7fa; ArcGIS added the web map typeKeywords and an extent itself. The stored map differed only in 16 whole coordinates written as integers. In read_9a, a Map widget on it worked and a Search choice moved the map, Text and Table; `--check` after R2 read it private and unchanged.
- What went right: the reads came before the script, and three of them changed it (the door already projects to Web Mercator; the kind keys on URLs; the first script was gone); the script reused the door's own functions, so what it sends is what 9b will send; every count was predicted before the run; the hash miss was read to its last byte before anything was concluded; the sharing was read after each hand step.
- Wrong hypotheses: that session 1's state.md was session 2's (the upload was older; session 2's notes were appended to it, not folded in); that rehearse_places.py was somewhere on disk (_sprint06/ is deleted at a session's end); that Map Viewer might misplace 4326 points (the door sends 102100); that the hash miss was the extent's long decimals (it was whole coordinates).
- Lessons: a rehearsal is evidence, so it is committed with its record; a portal stores numbers its own way, so the door's canonical form is the portal's; a kind built for one shape keys its checks on that shape's fields, and a new shape breaks them in silence; a state page is rewritten whole, or its header lies.
- Session shape: one chat held the forks' revision, three reads, the rehearsal script, its dry run, write, diff and checks, and this hand-off.

## Sprint 09 session 1's notes (the consultation; zip 9a built and run)

- What went right: the repo was checked first and Sprint 08's hand-off was found uncommitted and landed; every lean waited for its read, and three reads changed the design (Experience Builder's data panel, the coverage read, the real profiles); Kalli pushed for a retest of the Embed when Claude was ready to drop it, and it worked; every bucket draw printed its local sha256 before it was written, and every pinch count was predicted by a read before the code ran; the first real update went to a private test item first.
- Wrong hypotheses: that the towns' crack was a gap or a sliver (it is a pinch, and the House and Senate inherit it); that the dissolve ran in s2; that Experience Builder could not let a search steer an Embed; that redesigning around our own page was simpler than testing the original; that voice.py spoke for places; that profiles carried refusals per place; that 2 KB a place would hold the telling (3.2 KB at the median); that a hole's ring has an area.
- Lessons: a test with a noisy setup is not a test; read the real output as its reader would, by the thousand; when the design changes direction twice in a day, line up what the options share before choosing (the shared core made the choice cheap); show plainly, in public text, and keep claim words out by test, not by hope.
- Session shape: one long chat held the consultation, the Experience Builder reads, zip 9a with two small fixes, the whole run and this hand-off. The hand-off rule stands: zip 9b starts fresh from this page.

## Sprint 08 session 2's notes (zip 8b, its fixes, the run, Sprint 08 closed)

- What went right: three reads zips before any lean, a consultation iterated three times for failure modes and how the parts lock together; every guard built for this run fired on a real case before anything permanent (the receipt names, the manifest dataset, the schema, the local sha256 against the bucket's); the door's first `--check` found a bug zip 8a had hidden, before any move was refused for it.
- Wrong hypotheses: that state.md's labels matched its hashes; that renaming one experiment cured the collision (the method's recipe makes it); that the orphan guard made old receipts harmless (loam still reads them); that a union of both parents' notes was right; that two readers of a second parent needed changing (the credits made three); that a manifest match would be a false positive; that the door's HTML held no literal quote; that the sandbox tests had read the schema (they stubbed it).
- Lessons: read a receipt's own indicators before trusting its label; a name that goes public is forever, so read what makes it before the first write; every reader of a parent must learn about a second one, and the quiet failure (credits) outranks the loud one (notes); a stubbed contract is an unread one; a portal stores what it chooses, so compare what it stores.
- Session shape: one long chat held the consultation, zip 8b, three fixes, the whole run, the check and this hand-off. The hand-off rule stands: Sprint 09 starts fresh from this page.

## Sprint 08 session 1's notes (the door's consultation; zip 8a built and run)

- What went right: the reads came before every lean that rested on them (the code, the contracts, the ledger, the hand-made web map's own JSON, the dry runs, Esri's documentation); the door was tested against a fake portal before it met a real one, and the real one answered every call the way the fake did; the first write made one item and the second owed nothing.
- Wrong hypotheses: that the door would use Esri's arcgis package; that it might own a layer item beside the web map; that targets belong at repo level; that the door's gate decides exposure; that Map Viewer's JSON was the shape to copy; that the P items needed a new prefix; that an unhosted layer could not be saved; that a flag not yet built could sit in a runnable block (`--join` was run and refused).
- Lessons: label a command that is not built yet as after its zip and never draw it runnable; read the hand-made thing before writing its shape, and keep what a person chose; a referenced layer is as public as its URL; a broken button can be a stale page, so read the console first; a pointer that moves can be mirrored by every place that shows it, each mirror moving the same way.
- Session shape: one long chat held the plan, three reads zips, the contracts, the ledger, the ArcGIS reads, the consultation, the build, the run and this hand-off. The hand-off rule stands: zip 8b starts fresh from this page.

## Sprint 07 session 2's notes (zips 7b and 7c built and run; the first canonical object; the first web map)

- The reopening: Claude called Sprint 07 closed (d67ccb3) against this page's audit table, not the Master Plan tab's done-when, and wrote "closed" into this page and the progress report. Kalli asked "are you sure?"; the tab was read; the web-map half was missing, and Kalli chose to reopen and finish rather than move it to Sprint 08. A sprint closes against its own tab's done-when.
- Zip 7c's first dry run crashed on a Timestamp the clerk points carry (review_read_on): the display path had not inherited zip7b2's "an error is a refusal" fix. The same lesson twice: a new path inherits the old fixes or repeats the old crash.
- The towns' guard worked: the coverage check refused the copy rather than draw a crack between Gray and Windham (COVER-1).
- The whole suite was skipped four times before permanent writes in this session; nothing broke, and it stays the rule.

- What went right: the reads came before every lean that rested on them (the receipts' formats, the real envelope schema, two real receipts); the dry run was read before any write, and it found a crash and a design gap while both were still free to fix; the first write wrote exactly four keys in order and read back 392 through CloudFront.
- Wrong hypotheses: that a writer refusing all but Parquet stays useful; that a traceback's place in a saved file is where the run died; that tail -1 shows how a run ended; that an allow record could be written once per version.
- Lessons: read what a writer will meet before deciding what it refuses; an identity names only what cannot change without the thing changing; a batch read reports each surprise and goes on; run the whole suite before anything permanent.
- Session shape: one chat held the repo check, both reads zips, three builds, two dry runs, the first write and the hand-off. The hand-off rule stands: a long build starts fresh from state.md.

## Session 16's notes (zip 3a, built and run; Sprint 07 audited)

- What went right: the reads came before code twice (zip 3a's surface, then the ledger's own shape); the gate's three locks were found by reading decide() rather than by a failed publish; every refusal the run gave was loud and named its review.
- Wrong hypotheses: that Cision alone made The County's merge need editions; that named outlets would be one tier change; that a read after a failed run shows the new run (it showed the last good one, twice).
- Lessons: a read reports whatever ran last, so check a receipt's time against the run first; keep a merge whose need is in doubt, since it refuses loudly when no longer needed; a stack that refuses a missing input needs a named way to leave a source out.
- Session shape: one long chat held the plan, the Sprint 07 audit, zip 3a's consultation, build, two fixes and commit. The hand-off rule stands: a long build starts fresh from state.md.

## Session 15's notes (zips 2 and 2b, built and run)

- What went right: the consultation read 217 files before any code; the pure rules (verdicts, the standard's name checks) ran in the sandbox before the zip; the bed-backed tests were modelled on test_loam_values' own beds; 69 new and moved tests passed on their first run.
- Wrong hypotheses: that the full build hung (it was silent); that place_values' view made reads slow (0.0s); that a trigger's two margin ends bound its tiers (D-289); that only the outlets would be withheld (one license held the whole graph); that Contract 4's levels needed no filter.
- Lessons: a long command prints its progress; an input is anything a file holds, names and shares included; read the law's own text for a license and name a reading as a reading; `tail -60` can hide the line that matters, so filter for the lines wanted.
- Session shape: one chat held a consultation, two builds, two runs and the license research, and reached its tool limit once mid-build. The hand-off rule stands: a long build starts fresh from state.md.

## Before a build: session 13's retrospective

Every failure of session 13, sorted by cause, so the next build avoids them.

- Contracts unread (preventable): a receipt lacked crs (the envelope schema requires it; SCHEMA-1 warned); the oracle's row count assumed three indicators; test_district_values' table list and test_honest_values' D-18 premise were never read. Fix: the reads zip names every schema the output passes through and every test found by `git grep -l` on each identifier the change touches (module, function, field, manifest entry, preparation, and each decision whose premise changes), never a keyword or two.
- Untestable code read too lightly: R's needed grew with the rests_on cells and was reused for a count's margin. Fix: Claude reads every R branch it writes against its Python twin line by line, since the sandbox has no R; Kalli runs the oracle first.
- Documentation trusted over the file: cp1252 not ASCII, LANGUAGE text, Lit_P1 casing, county 000 on towns. Fix: read the file's bytes and rows before declaring anything; documentation is a hypothesis.
- Refusals decided without their real cases: unmatched Census towns refused though the file's 2019-era map was known. Fix: for each refusal rule, name the real rows that would hit it, from a read, before choosing refuse or hold.
- Numbers stated, not computed: 1,148 tests (1,166), a 58-line ledger block (44). Fix: compute in the sandbox or say about.
- Reads that hid their answer: head(20) cut a list; -rs hid FAILED lines; a one-liner printed a character count. Fix: count, then list; hunt failures with `python -m pytest -q --lf 2>&1 | tail -8`; one-liners print explicit words.
- Terminal and files: uploads not attached (say "attach X to your next message"); file names guessed (run find first); a missing package (check imports before a read); a key export split across two lines (keys live in conda env config vars, never pasted).
- Session shape: a long consultation chat hit the tool limit mid-build. Fix: the consultation ends by naming its reads zip; a long build starts fresh from state.md.
